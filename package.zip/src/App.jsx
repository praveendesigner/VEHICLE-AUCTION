import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { UserProvider } from './context/UserContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Pages
import Home from './pages/Home';
import Vehicles from './pages/Vehicles';
import VehicleDetails from './pages/VehicleDetails';
import Login from './pages/Login';
import Register from './pages/Register';
import BuyerDashboard from './pages/BuyerDashboard';
import SellerDashboard from './pages/SellerDashboard';
import AdminDashboard from './pages/AdminDashboard';

function App() {
    const { pathname } = useLocation();

    // Scroll to top on route change
    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    return (
        <UserProvider>
            <div className="min-h-screen flex flex-col font-sans selection:bg-blue-500/30">
                <Navbar />

                <main className="flex-grow">
                    <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/vehicles" element={<Vehicles />} />
                        <Route path="/vehicle/:id" element={<VehicleDetails />} />
                        <Route path="/login" element={<Login />} />
                        <Route path="/register" element={<Register />} />
                        <Route path="/buyer-dashboard" element={<BuyerDashboard />} />
                        <Route path="/seller-dashboard" element={<SellerDashboard />} />
                        <Route path="/admin-dashboard" element={<AdminDashboard />} />
                    </Routes>
                </main>

                {!pathname.includes('dashboard') && <Footer />}
            </div>
        </UserProvider>
    );
}

export default App;
