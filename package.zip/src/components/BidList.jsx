import React from 'react';
import { users } from '../data/mockData';

const BidList = ({ vehicleBids }) => {
    if (vehicleBids.length === 0) {
        return (
            <div className="text-center py-8 text-slate-500 italic">
                No bids yet. Be the first to bid!
            </div>
        );
    }

    // Sort bids by amount descending
    const sortedBids = [...vehicleBids].sort((a, b) => b.amount - a.amount);

    return (
        <div className="space-y-3">
            {sortedBids.map((bid, index) => {
                const bidder = users.find(u => u.id === bid.userId);
                return (
                    <div
                        key={bid.id}
                        className={`flex items-center justify-between p-3 rounded-xl border transition-all ${index === 0
                                ? 'bg-blue-600/10 border-blue-500/30'
                                : 'bg-slate-800/30 border-white/5'
                            }`}
                    >
                        <div className="flex items-center gap-3">
                            <img src={bidder?.avatar} alt={bidder?.name} className="w-8 h-8 rounded-full border border-white/10" />
                            <div>
                                <p className="text-sm font-bold text-white">{bidder?.name}</p>
                                <p className="text-[10px] text-slate-500">{new Date(bid.timestamp).toLocaleString()}</p>
                            </div>
                        </div>
                        <div className="text-right">
                            {index === 0 && <span className="text-[10px] bg-blue-600 text-white px-2 py-0.5 rounded-full uppercase font-black tracking-tighter mr-2">Highest</span>}
                            <span className={`font-bold ${index === 0 ? 'text-blue-400' : 'text-slate-300'}`}>
                                ${bid.amount.toLocaleString()}
                            </span>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default BidList;
