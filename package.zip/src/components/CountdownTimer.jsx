import React, { useState, useEffect } from 'react';

const CountdownTimer = ({ endTime, onExpire }) => {
    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

    function calculateTimeLeft() {
        const difference = +new Date(endTime) - +new Date();
        let timeLeft = {};

        if (difference > 0) {
            timeLeft = {
                days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
                seconds: Math.floor((difference / 1000) % 60),
            };
        }

        return timeLeft;
    }

    useEffect(() => {
        const timer = setInterval(() => {
            const remaining = calculateTimeLeft();
            setTimeLeft(remaining);

            if (Object.keys(remaining).length === 0) {
                clearInterval(timer);
                if (onExpire) onExpire();
            }
        }, 1000);

        return () => clearInterval(timer);
    }, [endTime]);

    if (Object.keys(timeLeft).length === 0) {
        return <span className="text-red-500 font-bold uppercase tracking-wider">Auction Ended</span>;
    }

    return (
        <div className="flex gap-2 text-sm font-mono text-blue-400">
            {timeLeft.days > 0 && <span>{timeLeft.days}d</span>}
            <span>{timeLeft.hours.toString().padStart(2, '0')}h</span>
            <span>{timeLeft.minutes.toString().padStart(2, '0')}m</span>
            <span>{timeLeft.seconds.toString().padStart(2, '0')}s</span>
        </div>
    );
};

export default CountdownTimer;
