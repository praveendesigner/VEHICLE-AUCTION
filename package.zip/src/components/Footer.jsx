import React from 'react';
import { Car, Mail, Phone, MapPin, Github, Twitter, Linkedin } from 'lucide-react';

const Footer = () => {
    return (
        <footer className="mt-20 border-t border-white/5 bg-slate-950/50 pt-16 pb-8">
            <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
                <div className="space-y-4">
                    <div className="flex items-center gap-2">
                        <div className="bg-blue-600 p-2 rounded-lg">
                            <Car className="text-white w-5 h-5" />
                        </div>
                        <span className="text-xl font-bold tracking-tight text-white">
                            Drive<span className="text-blue-500">Bid</span>
                        </span>
                    </div>
                    <p className="text-slate-500 text-sm leading-relaxed">
                        Leading the digital transformation of vehicle auctions. Transparency, speed, and premium service at your fingertips.
                    </p>
                    <div className="flex gap-4">
                        <a href="#" className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-blue-600 transition-all">
                            <Twitter size={18} />
                        </a>
                        <a href="#" className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-blue-600 transition-all">
                            <Github size={18} />
                        </a>
                        <a href="#" className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-blue-600 transition-all">
                            <Linkedin size={18} />
                        </a>
                    </div>
                </div>

                <div>
                    <h4 className="text-white font-bold mb-6">Quick Links</h4>
                    <ul className="space-y-3 text-sm text-slate-500">
                        <li><a href="/" className="hover:text-blue-400 transition-colors">Live Auctions</a></li>
                        <li><a href="/vehicles" className="hover:text-blue-400 transition-colors">Browse Vehicles</a></li>
                        <li><a href="/how-it-works" className="hover:text-blue-400 transition-colors">How it Works</a></li>
                        <li><a href="/pricing" className="hover:text-blue-400 transition-colors">Pricing & Fees</a></li>
                    </ul>
                </div>

                <div>
                    <h4 className="text-white font-bold mb-6">Support</h4>
                    <ul className="space-y-3 text-sm text-slate-500">
                        <li><a href="/faq" className="hover:text-blue-400 transition-colors">Help & FAQ</a></li>
                        <li><a href="/terms" className="hover:text-blue-400 transition-colors">Terms of Service</a></li>
                        <li><a href="/privacy" className="hover:text-blue-400 transition-colors">Privacy Policy</a></li>
                        <li><a href="/contact" className="hover:text-blue-400 transition-colors">Contact Support</a></li>
                    </ul>
                </div>

                <div>
                    <h4 className="text-white font-bold mb-6">Get in Touch</h4>
                    <ul className="space-y-4">
                        <li className="flex items-center gap-3 text-sm text-slate-500">
                            <MapPin size={18} className="text-blue-500" />
                            123 Auction Way, Digital City
                        </li>
                        <li className="flex items-center gap-3 text-sm text-slate-500">
                            <Phone size={18} className="text-blue-500" />
                            +1 (555) 000-0000
                        </li>
                        <li className="flex items-center gap-3 text-sm text-slate-500">
                            <Mail size={18} className="text-blue-500" />
                            support@drivebid.com
                        </li>
                    </ul>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-white/5 text-center text-slate-600 text-[10px] uppercase font-bold tracking-[0.2em]">
                © {new Date().getFullYear()} DriveBid Technologies. All Rights Reserved.
            </div>
        </footer>
    );
};

export default Footer;
