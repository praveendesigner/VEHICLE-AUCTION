import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import RoleSwitcher from './RoleSwitcher';
import { Car, LayoutDashboard, Home, Search, Gavel, Briefcase, Bell, X, CheckCircle2, AlertCircle } from 'lucide-react';

const Navbar = () => {
    const { currentUser, logout, notifications, markNotificationRead, clearNotification } = useUser();
    const location = useLocation();
    const navigate = useNavigate();
    const [showNotifications, setShowNotifications] = useState(false);

    const handleNotificationClick = (notif) => {
        markNotificationRead(notif.id);
        setShowNotifications(false);
        if (notif.link) {
            navigate(notif.link);
        }
    };

    const userNotifications = notifications ? notifications.filter(n => n.userId === currentUser?.id) : [];
    const unreadCount = userNotifications.filter(n => !n.read).length;

    const getNavLinks = () => {
        const baseLinks = [
            { name: 'Home', path: '/', icon: Home },
            { name: 'Browse', path: '/vehicles', icon: Search },
        ];

        if (!currentUser) return [...baseLinks, { name: 'Dashboard', path: '/login', icon: LayoutDashboard }];

        if (currentUser.role === 'admin') {
            return [...baseLinks, { name: 'Admin Control', path: '/admin-dashboard', icon: LayoutDashboard }];
        }

        return [
            ...baseLinks,
            { name: 'Bidding', path: '/buyer-dashboard', icon: Gavel },
            { name: 'Selling', path: '/seller-dashboard', icon: Briefcase },
        ];
    };

    const isDashboard = location.pathname.includes('dashboard');
    const navLinks = getNavLinks();

    return (
        <nav className={`sticky top-0 z-50 glass-card transition-all duration-500 ${isDashboard ? 'lg:ml-[300px] lg:mr-8 mx-4 my-4' : 'mx-4 my-4'} px-6 py-3 rounded-2xl flex items-center justify-between`}>
            <Link to="/" className="flex items-center gap-2 group">
                <div className="bg-blue-600 p-2 rounded-lg group-hover:rotate-12 transition-transform">
                    <Car className="text-white w-6 h-6" />
                </div>
                <span className="text-xl font-black text-white tracking-tighter">
                    Drive<span className="text-blue-500">Bid</span>
                </span>
            </Link>

            <div className="hidden md:flex items-center gap-8">
                {navLinks.map((link) => (
                    <Link
                        key={link.path}
                        to={link.path}
                        className={`flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-colors ${location.pathname === link.path ? 'text-blue-500' : 'text-slate-400 hover:text-white'
                            }`}
                    >
                        <link.icon size={18} />
                        {link.name}
                    </Link>
                ))}
            </div>

            <div className="flex items-center gap-3">
                {currentUser && (
                    <div className="relative">
                        <button
                            onClick={() => setShowNotifications(!showNotifications)}
                            className="relative p-2 text-slate-400 hover:text-white transition-colors"
                        >
                            <Bell size={20} />
                            {unreadCount > 0 && (
                                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-[10px] font-bold text-white rounded-full flex items-center justify-center">
                                    {unreadCount}
                                </span>
                            )}
                        </button>

                        {showNotifications && (
                            <div className="absolute right-0 mt-4 w-80 glass-card rounded-2xl border-white/10 shadow-2xl p-4 space-y-4 animate-in fade-in slide-in-from-top-2">
                                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                                    <h3 className="text-sm font-bold text-white uppercase tracking-widest">Notifications</h3>
                                    <button onClick={() => setShowNotifications(false)} className="text-slate-500 hover:text-white"><X size={16} /></button>
                                </div>

                                <div className="max-h-[300px] overflow-y-auto space-y-3 pr-1 text-left">
                                    {userNotifications.length === 0 ? (
                                        <p className="text-center py-8 text-xs text-slate-500 font-medium">No notifications yet.</p>
                                    ) : (
                                        userNotifications.map(n => (
                                            <div
                                                key={n.id}
                                                className={`p-3 rounded-xl border transition-all cursor-pointer ${n.read ? 'bg-transparent border-white/5 opacity-60' : 'bg-white/5 border-blue-500/20'}`}
                                                onClick={() => handleNotificationClick(n)}
                                            >
                                                <div className="flex gap-3 mb-1">
                                                    {n.type === 'success' ? <CheckCircle2 size={14} className="text-green-500 mt-0.5" /> : <AlertCircle size={14} className="text-blue-500 mt-0.5" />}
                                                    <p className="text-xs font-medium text-slate-300 leading-tight">{n.message}</p>
                                                </div>
                                                <div className="flex justify-between items-center">
                                                    <span className="text-[10px] text-slate-600 font-bold uppercase">{new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                                    <button
                                                        onClick={(e) => { e.stopPropagation(); clearNotification(n.id); }}
                                                        className="text-[10px] text-slate-600 hover:text-red-400 font-bold uppercase tracking-tighter"
                                                    >
                                                        Remove
                                                    </button>
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {currentUser ? (
                    <>
                        <RoleSwitcher />
                        <button
                            onClick={logout}
                            className="text-xs font-bold text-slate-500 hover:text-red-400 transition-colors uppercase tracking-widest border-l border-white/10 pl-4 ml-2"
                        >
                            Logout
                        </button>
                    </>
                ) : (
                    <Link to="/login" className="btn-primary text-xs py-2 px-4">
                        Sign In
                    </Link>
                )}
            </div>
        </nav>
    );
};

export default Navbar;
