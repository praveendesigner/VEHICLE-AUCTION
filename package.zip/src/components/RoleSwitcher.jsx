import React from 'react';
import { useUser } from '../context/UserContext';

const RoleSwitcher = () => {
    const { currentUser, allUsers, switchRole } = useUser();

    if (!currentUser) return null;

    return (
        <div className="flex items-center gap-3 bg-slate-800/50 p-1.5 pr-4 rounded-full border border-white/5 group hover:bg-slate-800 transition-colors">
            <div className="w-8 h-8 rounded-full border border-blue-500/50 overflow-hidden">
                <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex flex-col">
                <span className="text-[10px] font-black text-white uppercase tracking-tighter leading-none mb-1">{currentUser.name}</span>
                <span className="text-[9px] text-blue-400 font-bold uppercase tracking-widest leading-none">{currentUser.role}</span>
            </div>
        </div>
    );
};

export default RoleSwitcher;
