import React from 'react';
import { Link } from 'react-router-dom';
import CountdownTimer from './CountdownTimer';
import { Gauge, Fuel, Calendar, ArrowUpRight } from 'lucide-react';

const VehicleCard = ({ vehicle }) => {
    return (
        <div className="group glass-card rounded-2xl overflow-hidden hover:border-blue-500/50 transition-all duration-500 hover:shadow-2xl hover:shadow-blue-500/10">
            <div className="relative h-48 overflow-hidden bg-slate-800">
                <img
                    src={vehicle.images[0]}
                    alt={vehicle.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    onError={(e) => {
                        e.target.src = `https://picsum.photos/seed/${vehicle.id}/800/600`;
                    }}
                />
                <div className="absolute top-3 right-3 bg-slate-900/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-white border border-white/10">
                    <CountdownTimer endTime={vehicle.endTime} />
                </div>
            </div>

            <div className="p-5">
                <div className="flex justify-between items-start mb-2">
                    <div>
                        <h3 className="text-lg font-bold text-white mb-1 group-hover:text-blue-400 transition-colors">
                            {vehicle.name}
                        </h3>
                        <p className="text-sm text-slate-400 font-medium">{vehicle.brand} • {vehicle.year}</p>
                    </div>
                    <div className="text-right">
                        <span className="text-xs text-slate-500 block uppercase font-bold tracking-widest">Current Bid</span>
                        <span className="text-xl font-black text-blue-500">${vehicle.currentBid.toLocaleString()}</span>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-2 py-4 border-y border-white/5 my-4">
                    <div className="flex flex-col items-center gap-1">
                        <Fuel size={16} className="text-slate-500" />
                        <span className="text-[10px] text-slate-400 font-medium">{vehicle.fuel}</span>
                    </div>
                    <div className="flex flex-col items-center gap-1 border-x border-white/5">
                        <Gauge size={16} className="text-slate-500" />
                        <span className="text-[10px] text-slate-400 font-medium">{vehicle.kmDriven} km</span>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                        <Calendar size={16} className="text-slate-500" />
                        <span className="text-[10px] text-slate-400 font-medium">{vehicle.year}</span>
                    </div>
                </div>

                <Link
                    to={`/vehicle/${vehicle.id}`}
                    className="w-full flex items-center justify-center gap-2 bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white py-2.5 rounded-xl font-bold transition-all duration-300"
                >
                    View Auction <ArrowUpRight size={18} />
                </Link>
            </div>
        </div>
    );
};

export default VehicleCard;
