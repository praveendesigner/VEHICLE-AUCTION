import React, { createContext, useState, useContext, useEffect } from 'react';
import { users, vehicles, bids, employees as initialEmployees, deposits as initialDeposits, vehiclePayments as initialPayments } from '../data/mockData';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
    const [allUsers, setAllUsers] = useState(users);
    const [currentUser, setCurrentUser] = useState(null);
    const [allVehicles, setAllVehicles] = useState(vehicles);
    const [allBids, setAllBids] = useState(bids);
    const [userDocuments, setUserDocuments] = useState([]);
    const [drafts, setDrafts] = useState([]);
    const [pendingVehicles, setPendingVehicles] = useState([]);
    const [notifications, setNotifications] = useState([]);
    const [employees, setEmployees] = useState(initialEmployees);
    const [deposits, setDeposits] = useState(initialDeposits);
    const [vehiclePayments, setVehiclePayments] = useState(initialPayments);

    useEffect(() => {
        const DATA_VERSION = 'v16'; // Forced reset for simplified static mock data structure
        const savedVersion = localStorage.getItem('data_version');
        const savedUser = localStorage.getItem('currentUser');
        const savedAllUsers = localStorage.getItem('allUsers');
        const savedAllVehicles = localStorage.getItem('allVehicles');
        const savedAllBids = localStorage.getItem('allBids');
        const savedPendingVehicles = localStorage.getItem('pendingVehicles');
        const savedNotifications = localStorage.getItem('notifications');
        const savedUserDocuments = localStorage.getItem('userDocuments');
        const savedDrafts = localStorage.getItem('drafts');

        if (savedAllUsers) setAllUsers(JSON.parse(savedAllUsers));

        let initialVehicles = vehicles;
        if (savedVersion === DATA_VERSION && savedAllVehicles) {
            initialVehicles = JSON.parse(savedAllVehicles);
        } else {
            localStorage.setItem('allVehicles', JSON.stringify(vehicles));
            localStorage.setItem('data_version', DATA_VERSION);
        }
        setAllVehicles(initialVehicles);

        if (savedAllBids) setAllBids(JSON.parse(savedAllBids));
        if (savedPendingVehicles) setPendingVehicles(JSON.parse(savedPendingVehicles));
        if (savedNotifications) setNotifications(JSON.parse(savedNotifications));
        if (savedUserDocuments) setUserDocuments(JSON.parse(savedUserDocuments));
        if (savedDrafts) setDrafts(JSON.parse(savedDrafts));

        const savedEmployees = localStorage.getItem('employees');
        const savedDeposits = localStorage.getItem('deposits');
        const savedPayments = localStorage.getItem('vehiclePayments');

        if (savedEmployees) setEmployees(JSON.parse(savedEmployees));
        if (savedDeposits) setDeposits(JSON.parse(savedDeposits));
        if (savedPayments) setVehiclePayments(JSON.parse(savedPayments));

        if (savedUser) {
            setCurrentUser(JSON.parse(savedUser));
        } else {
            setCurrentUser(users[2]);
        }
    }, []);

    const login = (email, password) => {
        const user = allUsers.find(u => u.email === email && u.password === password);
        if (user) {
            setCurrentUser(user);
            localStorage.setItem('currentUser', JSON.stringify(user));
            return { success: true, user };
        }
        return { success: false, message: 'Invalid email or password' };
    };

    const register = (userData) => {
        const exists = allUsers.find(u => u.email === userData.email);
        if (exists) return { success: false, message: 'Email already registered' };

        const newUser = {
            ...userData,
            id: `u${allUsers.length + 1}`,
            status: 'Active',
            mobile: userData.mobile || '',
            avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userData.name}`
        };

        const updatedUsers = [...allUsers, newUser];
        setAllUsers(updatedUsers);
        localStorage.setItem('allUsers', JSON.stringify(updatedUsers));
        setCurrentUser(newUser);
        localStorage.setItem('currentUser', JSON.stringify(newUser));
        return { success: true, user: newUser };
    };

    const updateProfile = (userId, newData) => {
        const updatedUsers = allUsers.map(u => u.id === userId ? { ...u, ...newData } : u);
        setAllUsers(updatedUsers);
        localStorage.setItem('allUsers', JSON.stringify(updatedUsers));
        if (currentUser?.id === userId) {
            const updatedCurrent = { ...currentUser, ...newData };
            setCurrentUser(updatedCurrent);
            localStorage.setItem('currentUser', JSON.stringify(updatedCurrent));
        }
        return { success: true };
    };

    const uploadDocument = (docData) => {
        const newDoc = {
            ...docData,
            id: Date.now(),
            userId: currentUser.id,
            timestamp: new Date().toISOString()
        };
        const updatedDocs = [newDoc, ...userDocuments];
        setUserDocuments(updatedDocs);
        localStorage.setItem('userDocuments', JSON.stringify(updatedDocs));
        return { success: true };
    };

    const saveDraft = (vehicleData) => {
        const newDraft = {
            ...vehicleData,
            id: `draft-${Date.now()}`,
            sellerId: currentUser.id,
            status: 'Draft',
            updatedAt: new Date().toISOString()
        };
        const updatedDrafts = [newDraft, ...drafts];
        setDrafts(updatedDrafts);
        localStorage.setItem('drafts', JSON.stringify(updatedDrafts));
        return { success: true };
    };

    const placeBid = (vehicleId, amount) => {
        const newBid = {
            id: `b${allBids.length + 1}`,
            vehicleId,
            userId: currentUser.id,
            amount,
            timestamp: new Date().toISOString()
        };

        const updatedBids = [...allBids, newBid];
        setAllBids(updatedBids);
        localStorage.setItem('allBids', JSON.stringify(updatedBids));

        const updatedVehicles = allVehicles.map(v =>
            v.id === vehicleId ? { ...v, currentBid: amount } : v
        );
        setAllVehicles(updatedVehicles);
        localStorage.setItem('allVehicles', JSON.stringify(updatedVehicles));

        return { success: true };
    };

    const addNotification = (userId, message, type = 'info', link = null) => {
        const newNotif = {
            id: Date.now(),
            userId,
            message,
            type,
            link,
            read: false,
            timestamp: new Date().toISOString()
        };
        setNotifications(prev => {
            const updated = [newNotif, ...prev];
            localStorage.setItem('notifications', JSON.stringify(updated));
            return updated;
        });
    };

    const clearNotification = (id) => {
        setNotifications(prev => {
            const updated = prev.filter(n => n.id !== id);
            localStorage.setItem('notifications', JSON.stringify(updated));
            return updated;
        });
    };

    const markNotificationRead = (id) => {
        setNotifications(prev => {
            const updated = prev.map(n => n.id === id ? { ...n, read: true } : n);
            localStorage.setItem('notifications', JSON.stringify(updated));
            return updated;
        });
    };

    const switchRole = (userId) => {
        const user = allUsers.find(u => u.id === userId);
        if (user) {
            setCurrentUser(user);
            localStorage.setItem('currentUser', JSON.stringify(user));
        }
    };

    const logout = () => {
        setCurrentUser(null);
        localStorage.removeItem('currentUser');
    };

    const submitListing = (vehicleData) => {
        // If it was a draft, remove it
        if (vehicleData.id && vehicleData.id.startsWith('draft-')) {
            setDrafts(prev => prev.filter(d => d.id !== vehicleData.id));
            localStorage.setItem('drafts', JSON.stringify(drafts.filter(d => d.id !== vehicleData.id)));
        }

        const newRequest = {
            ...vehicleData,
            id: `pv${Date.now()}`,
            sellerId: currentUser.id,
            status: 'Pending',
            submittedAt: new Date().toISOString(),
            currentBid: vehicleData.basePrice || vehicleData.targetPrice,
        };

        const updatedPending = [...pendingVehicles, newRequest];
        setPendingVehicles(updatedPending);
        localStorage.setItem('pendingVehicles', JSON.stringify(updatedPending));

        // Notify admin
        allUsers.filter(u => u.role === 'admin').forEach(admin => {
            addNotification(admin.id, `New listing request from ${currentUser.name}: ${vehicleData.name}`, 'warning', '/admin-dashboard');
        });

        return { success: true };
    };

    const addVehicle = (vehicleData) => {
        const newVehicle = {
            ...vehicleData,
            id: `v${allVehicles.length + 1}`,
            sellerId: currentUser.id,
            status: 'Live',
            endTime: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(),
            currentBid: vehicleData.basePrice,
        };

        const updatedVehicles = [newVehicle, ...allVehicles];
        setAllVehicles(updatedVehicles);
        localStorage.setItem('allVehicles', JSON.stringify(updatedVehicles));
        return { success: true };
    };

    const approveListing = (requestId) => {
        const request = pendingVehicles.find(pv => pv.id === requestId);
        if (!request) return { success: false };

        const newVehicleId = `v${allVehicles.length + 1}`;
        const newVehicle = {
            ...request,
            id: newVehicleId,
            status: 'Live',
            endTime: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(),
        };

        // Update All Vehicles
        setAllVehicles(prev => {
            const updated = [newVehicle, ...prev];
            try {
                localStorage.setItem('allVehicles', JSON.stringify(updated));
            } catch (e) {
                console.error("Storage limit exceeded, but state updated.");
            }
            return updated;
        });

        // Update Pending Vehicles
        setPendingVehicles(prev => {
            const updated = prev.filter(pv => pv.id !== requestId);
            try {
                localStorage.setItem('pendingVehicles', JSON.stringify(updated));
            } catch (e) {
                console.error("Storage limit exceeded, but state updated.");
            }
            return updated;
        });

        // Notify seller
        addNotification(request.sellerId, `Your listing "${request.name}" has been approved and is now LIVE!`, 'success', `/vehicle-details/${newVehicleId}`);

        return { success: true };
    };

    const rejectListing = (requestId) => {
        const request = pendingVehicles.find(pv => pv.id === requestId);

        setPendingVehicles(prev => {
            const updated = prev.filter(pv => pv.id !== requestId);
            try {
                localStorage.setItem('pendingVehicles', JSON.stringify(updated));
            } catch (e) {
                console.error("Storage limit exceeded, but state updated.");
            }
            return updated;
        });

        if (request) {
            addNotification(request.sellerId, `Your listing "${request.name}" was rejected by the admin.`, 'error', '/seller-dashboard');
        }
        return { success: true };
    };

    const toggleUserStatus = (userId) => {
        const updated = allUsers.map(u => u.id === userId ? { ...u, status: u.status === 'Active' ? 'Inactive' : 'Active' } : u);
        setAllUsers(updated);
        localStorage.setItem('allUsers', JSON.stringify(updated));
    };

    const toggleEmployeeStatus = (empId) => {
        const updated = employees.map(e => e.id === empId ? { ...e, status: e.status === 'Active' ? 'Inactive' : 'Active' } : e);
        setEmployees(updated);
        localStorage.setItem('employees', JSON.stringify(updated));
    };

    const overrideAuction = (vehicleId, status) => {
        const updated = allVehicles.map(v => v.id === vehicleId ? { ...v, status } : v);
        setAllVehicles(updated);
        localStorage.setItem('allVehicles', JSON.stringify(updated));
    };

    const updateDepositStatus = (depositId, status) => {
        const updated = deposits.map(d => d.id === depositId ? { ...d, status } : d);
        setDeposits(updated);
        localStorage.setItem('deposits', JSON.stringify(updated));
    };

    const updateVehicle = (vehicleId, updatedData) => {
        const updatedVehicles = allVehicles.map(v =>
            v.id === vehicleId ? { ...v, ...updatedData } : v
        );
        setAllVehicles(updatedVehicles);
        localStorage.setItem('allVehicles', JSON.stringify(updatedVehicles));

        // Also update if it's in pending
        const updatedPending = pendingVehicles.map(v =>
            v.id === vehicleId ? { ...v, ...updatedData } : v
        );
        if (JSON.stringify(pendingVehicles) !== JSON.stringify(updatedPending)) {
            setPendingVehicles(updatedPending);
            localStorage.setItem('pendingVehicles', JSON.stringify(updatedPending));
        }

        return { success: true };
    };

    const addEmployee = (emp) => {
        const newEmp = { ...emp, id: `e${employees.length + 1}`, status: 'Active', joinedDate: new Date().toISOString().split('T')[0] };
        const updated = [...employees, newEmp];
        setEmployees(updated);
        localStorage.setItem('employees', JSON.stringify(updated));
    };

    return (
        <UserContext.Provider value={{
            currentUser,
            allUsers,
            allVehicles,
            allBids,
            pendingVehicles,
            notifications,
            employees,
            deposits,
            vehiclePayments,
            userDocuments,
            drafts,
            login,
            register,
            updateProfile,
            uploadDocument,
            saveDraft,
            placeBid,
            submitListing,
            addVehicle,
            approveListing,
            rejectListing,
            clearNotification,
            markNotificationRead,
            switchRole,
            logout,
            toggleUserStatus,
            toggleEmployeeStatus,
            overrideAuction,
            updateDepositStatus,
            addEmployee,
            updateVehicle
        }}>
            {children}
        </UserContext.Provider>
    );
};

export const useUser = () => {
    const context = useContext(UserContext);
    if (!context) {
        throw new Error('useUser must be used within a UserProvider');
    }
    return context;
};
