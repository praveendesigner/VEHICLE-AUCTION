// ==============================================================================
// MOCK DATA CONFIGURATION
// ==============================================================================
// This file contains all the sample data used in the application.
// You can edit the "vehicles" list directly to add, remove, or modify listings.
//
// HELPER FUNCTIONS:
// These help keep dates and times consistent relative to when you run the app.
// ==============================================================================

const now = new Date();

// Returns a date in the future (in hours) - Used for Auction End Time
const getFutureDate = (hours) => new Date(now.getTime() + hours * 60 * 60 * 1000).toISOString();

// Returns a date in the past (in minutes) - Used for Bid Timestamps
const getPastDate = (minutes) => new Date(now.getTime() - minutes * 60 * 1000).toISOString();


// ==============================================================================
// VEHICLE LISTINGS
// Edit this array to change the vehicles displayed in the app.
// You can change any field, including images, prices, and features.
// ==============================================================================
export const vehicles = [
    // --- SPECIAL HIGHLIGHTS ---
    {
        id: 'v1',
        name: 'Tesla model S Plaid',
        brand: 'Tesla',
        model: 'Model S',
        year: 2023,
        fuel: 'Electric',
        kmDriven: 5000,
        basePrice: 85000,
        currentBid: 92000,
        sellerId: 'u2',
        category: 'Sedan',
        endTime: getFutureDate(2), // Ends in 2 hours
        images: ['https://images.unsplash.com/photo-1740170512929-226dd523462b?q=80&w=1469&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Live',
        description: 'Pristine condition Model S Plaid. Top of the line electric performance.',
        transmission: 'Automatic',
        ownerType: 'First',
        engineCC: 0, // Electric
        location: 'California, USA',
        power: 1020, // HP
        features: ['Autopilot', 'Ludicrous Mode', 'Yoke Steering', '21" Arachnid Wheels']
    },
    {
        id: 'v2',
        name: 'Porsche 911 GT3',
        brand: 'Porsche',
        model: '911 GT3',
        year: 2022,
        fuel: 'Petrol',
        kmDriven: 1200,
        basePrice: 160000,
        currentBid: 175000,
        sellerId: 'u2',
        category: 'Sedan',
        endTime: getFutureDate(24), // Ends in 24 hours
        images: ['https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=1000'],
        status: 'Live',
        description: 'Track-ready performance with naturally aspirated engine. Finished in GT Silver Metallic.',
        transmission: 'PDK Automatic',
        ownerType: 'First',
        engineCC: 4000,
        location: 'Munich, Germany',
        power: 502,
        features: ['Carbon Ceramic Brakes', 'Front Axle Lift', 'Sport Chrono Package', 'Carbon Bucket Seats']
    },
    {
        id: 'v4',
        name: 'Mercedes-Benz G63 AMG',
        brand: 'Mercedes-Benz',
        model: 'G63 AMG',
        year: 2023,
        fuel: 'Petrol',
        kmDriven: 3500,
        basePrice: 180000,
        currentBid: 192000,
        sellerId: 'u2',
        category: 'SUV',
        endTime: getFutureDate(5),
        images: ['https://images.unsplash.com/photo-1520031441872-265e4ff70366?auto=format&fit=crop&q=80&w=1000'],
        status: 'Live',
        description: 'Iconic luxury SUV with powerful V8 biturbo engine. Obsidian Black exterior.',
        transmission: 'Automatic',
        ownerType: 'First',
        engineCC: 4000,
        location: 'Dubai, UAE',
        power: 577,
        features: ['Burmester 3D Sound', 'Massage Seats', 'Night Package', 'AMG Ride Control']
    },

    // --- BUSES ---
    {
        id: 'bus1',
        name: 'Mercedes-Benz Tourismo',
        brand: 'Mercedes',
        model: 'Tourismo',
        year: 2020,
        fuel: 'Diesel',
        kmDriven: 120000,
        basePrice: 90000,
        currentBid: 95000,
        sellerId: 'u2',
        category: 'Bus',
        endTime: getFutureDate(48),
        images: ['https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80'],
        status: 'Live',
        description: 'Reliable long-distance coach with 50 seats and restroom.',
        transmission: 'Automatic',
        ownerType: 'Company',
        engineCC: 10700,
        location: 'London, UK',
        power: 428,
        features: ['50 Seats', 'Restroom', 'WiFi', 'Air Conditioning']
    },
    {
        id: 'bus2',
        name: 'Volvo 9700',
        brand: 'Volvo',
        model: '9700',
        year: 2019,
        fuel: 'Diesel',
        kmDriven: 150000,
        basePrice: 85000,
        currentBid: 88000,
        sellerId: 'u2',
        category: 'Bus',
        endTime: getFutureDate(12),
        images: ['https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=800&q=80'],
        status: 'Live',
        description: 'Comfortable passenger layout. Ideal for city to city travel.',
        transmission: 'Automatic',
        ownerType: 'Company',
        engineCC: 12800,
        location: 'Berlin, Germany',
        power: 460,
        features: ['Adjustable Seats', 'USB Charging', 'Panoramic Window']
    },

    // --- HEAVY MACHINERY ---
    {
        id: 'hm1',
        name: 'Komatsu Excavator',
        brand: 'Komatsu',
        model: 'PC210',
        year: 2021,
        fuel: 'Diesel',
        kmDriven: 2000, // hours
        basePrice: 120000,
        currentBid: 125000,
        sellerId: 'u2',
        category: 'Heavy Machinery',
        endTime: getFutureDate(72),
        images: ['https://images.unsplash.com/photo-1669902081596-18497f52659e?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Live',
        description: 'Heavy duty excavator for construction sites. Excellent maintenance history.',
        transmission: 'Hydrostatic',
        ownerType: 'First',
        engineCC: 6700,
        location: 'Texas, USA',
        power: 165,
        features: ['Hydraulic Thumb', 'Rear Camera', 'Air Suspension Seat']
    },
    {
        id: 'hm2',
        name: 'JCB Backhoe Loader',
        brand: 'JCB',
        model: '3CX',
        year: 2020,
        fuel: 'Diesel',
        kmDriven: 3000, // hours
        basePrice: 60000,
        currentBid: 62000,
        sellerId: 'u2',
        category: 'Heavy Machinery',
        endTime: getFutureDate(6),
        images: ['https://images.unsplash.com/photo-1629807473015-41699c4471b5?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Live',
        description: 'Versatile backhoe loader. Ready for immediate work.',
        transmission: 'Manual',
        ownerType: 'Second',
        engineCC: 4400,
        location: 'Manchester, UK',
        power: 74,
        features: ['4WD', 'Extradig', 'Hammer Lines']
    },
    {
        id: 'hm3',
        name: 'John Deere Loader',
        brand: 'John Deere',
        model: '544 P',
        year: 2022,
        fuel: 'Diesel',
        kmDriven: 1500, // hours
        basePrice: 130000,
        currentBid: 135000,
        sellerId: 'u2',
        category: 'Heavy Machinery',
        endTime: getFutureDate(96),
        images: ['https://images.unsplash.com/photo-1675600360075-5564fe1a7e5a?q=80&w=1467&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Upcoming',
        description: 'Efficient wheel loader with high lift capacity.',
        transmission: 'Automatic',
        ownerType: 'First',
        engineCC: 6800,
        location: 'Ohio, USA',
        power: 166,
        features: ['High Lift', 'Ride Control', 'Quick Coupler']
    },

    // --- MOTOR BIKES ---
    {
        id: 'mb1',
        name: 'Ducati Panigale V4',
        brand: 'Ducati',
        model: 'Panigale V4',
        year: 2023,
        fuel: 'Petrol',
        kmDriven: 500,
        basePrice: 25000,
        currentBid: 28000,
        sellerId: 'u2',
        category: 'Motor Bikes',
        endTime: getFutureDate(3),
        images: ['https://images.unsplash.com/photo-1645818481640-c0be89188521?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Live',
        description: 'Superbike performance from the Italian legend.',
        transmission: 'Manual',
        ownerType: 'First',
        engineCC: 1103,
        location: 'Milan, Italy',
        power: 210,
        features: ['ABS Cornering', 'Traction Control', 'Quick Shifter']
    },
    {
        id: 'mb2',
        name: 'BMW Bike ',
        brand: 'BMW',
        model: 'R 1250 GS',
        year: 2022,
        fuel: 'Petrol',
        kmDriven: 8000,
        basePrice: 18000,
        currentBid: 19500,
        sellerId: 'u2',
        category: 'Motor Bikes',
        endTime: getFutureDate(30),
        images: ['https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Live',
        description: 'The ultimate adventure touring motorcycle.',
        transmission: 'Manual',
        ownerType: 'First',
        engineCC: 1254,
        location: 'Munich, Germany',
        power: 136,
        features: ['Heated Grips', 'ESA', 'Cruise Control']
    },

    // --- SUVs ---
    {
        id: 'suv1',
        name: 'Range Rover Sport',
        brand: 'Land Rover',
        model: 'Range Rover Sport',
        year: 2022,
        fuel: 'Petrol',
        kmDriven: 15000,
        basePrice: 95000,
        currentBid: 98000,
        sellerId: 'u2',
        category: 'SUV',
        endTime: getFutureDate(18),
        images: ['https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80'],
        status: 'Live',
        description: 'Luxury meets off-road capability capability.',
        transmission: 'Automatic',
        ownerType: 'First',
        engineCC: 3000,
        location: 'London, UK',
        power: 395,
        features: ['Meridian Sound', 'Air Suspension', 'Head-up Display']
    },
    {
        id: 'suv2',
        name: 'Jeep Wrangler',
        brand: 'Jeep',
        model: 'Wrangler Rubicon',
        year: 2021,
        fuel: 'Petrol',
        kmDriven: 25000,
        basePrice: 45000,
        currentBid: 48000,
        sellerId: 'u2',
        category: 'SUV',
        endTime: getFutureDate(40),
        images: ['https://images.unsplash.com/photo-1506015391300-4802dc74de2e?q=80&w=1559&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Live',
        description: 'The ultimate off-road vehicle. Ready for trails.',
        transmission: 'Automatic',
        ownerType: 'Second',
        engineCC: 3600,
        location: 'Colorado, USA',
        power: 285,
        features: ['Locking Differentials', 'Sway Bar Disconnect', 'Hard Top']
    },

    // --- SEDANS ---
    {
        id: 'sed1',
        name: 'BMW 5 Series',
        brand: 'BMW',
        model: '530i',
        year: 2021,
        fuel: 'Petrol',
        kmDriven: 30000,
        basePrice: 40000,
        currentBid: 42000,
        sellerId: 'u2',
        category: 'Sedan',
        endTime: getFutureDate(5),
        images: ['https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=800&q=80'],
        status: 'Live',
        description: 'Executive sedan with sporty dynamics and comfort.',
        transmission: 'Automatic',
        ownerType: 'First',
        engineCC: 2000,
        location: 'New York, USA',
        power: 248,
        features: ['Leather Seats', 'Navigation', 'Sunroof']
    },
    {
        id: 'sed2',
        name: 'Audi A6',
        brand: 'Audi',
        model: 'A6',
        year: 2022,
        fuel: 'Petrol',
        kmDriven: 18000,
        basePrice: 45000,
        currentBid: 46500,
        sellerId: 'u2',
        category: 'Sedan',
        endTime: getFutureDate(22),
        images: ['https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=800&q=80'],
        status: 'Live',
        description: 'Tech-focused luxury sedan with Quattro AWD.',
        transmission: 'Trptronic',
        ownerType: 'First',
        engineCC: 2000,
        location: 'Seattle, USA',
        power: 261,
        features: ['Virtual Cockpit', 'Bang & Olufsen', '360 Camera']
    },

    // --- NORMAL CARS ---
    {
        id: 'nc1',
        name: 'Honda Civic',
        brand: 'Honda',
        model: 'Civic',
        year: 2020,
        fuel: 'Petrol',
        kmDriven: 45000,
        basePrice: 18000,
        currentBid: 19500,
        sellerId: 'u2',
        category: 'Normal Cars',
        endTime: getFutureDate(10),
        images: ['https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=800&q=80'],
        status: 'Live',
        description: 'Reliable daily commuter with great fuel economy.',
        transmission: 'CVT',
        ownerType: 'First',
        engineCC: 1500,
        location: 'Los Angeles, USA',
        power: 158,
        features: ['Apple CarPlay', 'Lane Keep Assist', 'Backup Camera']
    },
    {
        id: 'nc2',
        name: 'Toyota Corolla',
        brand: 'Toyota',
        model: 'Corolla',
        year: 2019,
        fuel: 'Petrol',
        kmDriven: 55000,
        basePrice: 16000,
        currentBid: 17200,
        sellerId: 'u2',
        category: 'Normal Cars',
        endTime: getFutureDate(8),
        images: ['https://images.unsplash.com/photo-1638618164682-12b986ec2a75?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Live',
        description: 'Efficient and durable sedan. Low maintenance costs.',
        transmission: 'CVT',
        ownerType: 'Second',
        engineCC: 1800,
        location: 'Chicago, USA',
        power: 139,
        features: ['Bluetooth', 'Cruise Control', 'Keyless Entry']
    },
    {
        id: 'nc3',
        name: 'Sold Ford Focus',
        brand: 'Ford',
        model: 'Focus',
        year: 2018,
        fuel: 'Petrol',
        kmDriven: 60000,
        basePrice: 12000,
        currentBid: 14000,
        sellerId: 'u2',
        category: 'Normal Cars',
        endTime: getPastDate(120), // Recently ended
        images: ['https://images.unsplash.com/photo-1708849894321-2c9bc515df0e?q=80&w=1934&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'],
        status: 'Sold',
        description: 'Compact hatchback. Fun to drive.',
        transmission: 'Automatic',
        ownerType: 'Second',
        engineCC: 2000,
        location: 'Detroit, USA',
        power: 160,
        features: ['Heated Seats', 'Sync 3', 'Alloy Wheels']
    }
];

// ==============================================================================
// USER DATA
// ==============================================================================
export const users = [
    {
        id: 'u1', name: 'Admin User', role: 'admin', email: 'admin@drivebid.com',
        password: 'admin123', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Admin'
    },
    {
        id: 'u2', name: 'John Seller', role: 'seller', email: 'john@seller.com',
        password: 'seller123', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John'
    },
    {
        id: 'u3', name: 'Sarah Buyer', role: 'buyer', email: 'sarah@buyer.com',
        password: 'buyer123', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah'
    },
];

// ==============================================================================
// EMPLOYEE DATA
// ==============================================================================
export const employees = [
    { id: 'e1', name: 'Alice Admin', role: 'admin', email: 'alice@drivebid.com', status: 'Active', joinedDate: '2023-01-15' },
    { id: 'e2', name: 'Bob Ops', role: 'Operations', email: 'bob@drivebid.com', status: 'Active', joinedDate: '2023-03-20' },
    { id: 'e3', name: 'Charlie Finance', role: 'Finance', email: 'charlie@drivebid.com', status: 'Inactive', joinedDate: '2023-05-10' },
];

// ==============================================================================
// TRANSACTION DATA
// ==============================================================================
export const deposits = [
    { id: 'd1', userId: 'u3', amount: 5000, status: 'Paid', method: 'Wire Transfer', date: '2024-02-01' },
    { id: 'd2', userId: 'u3', amount: 2000, status: 'Refunded', method: 'Credit Card', date: '2024-01-15' },
];

export const vehiclePayments = [
    { id: 'p1', vehicleId: 'v1', userId: 'u3', amount: 92000, status: 'Completed', method: 'Bank Transfer', date: '2024-02-05', ref: 'INV-001' },
    { id: 'p2', vehicleId: 'v2', userId: 'u3', amount: 175000, status: 'Pending', method: 'Financing', date: '2024-02-10', ref: 'INV-002' },
];

export const bids = [
    { id: 'b1', vehicleId: 'v1', userId: 'u3', amount: 88000, timestamp: getPastDate(60) },
    { id: 'b2', vehicleId: 'v1', userId: 'u3', amount: 92000, timestamp: getPastDate(15) },
    { id: 'b3', vehicleId: 'v2', userId: 'u3', amount: 165000, timestamp: getPastDate(120) },
    { id: 'b4', vehicleId: 'v2', userId: 'u3', amount: 175000, timestamp: getPastDate(45) },
];
