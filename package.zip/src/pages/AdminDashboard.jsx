import React, { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import CountdownTimer from '../components/CountdownTimer';
import {
    LayoutDashboard,
    Package,
    Gavel,
    Users,
    UserCircle,
    Briefcase,
    CreditCard,
    BarChart3,
    Search,
    Filter,
    Plus,
    MoreVertical,
    Activity,
    CheckCircle2,
    XCircle,
    Clock,
    TrendingUp,
    Download,
    Eye,
    ChevronRight,
    ArrowUpRight,
    ArrowDownLeft,
    ShieldCheck,
    X,
    Camera,
    ArrowUpDown,
    LogOut,
    AlertCircle,
    ShieldAlert,
    Car
} from 'lucide-react';
import { useUser } from '../context/UserContext';

const AdminDashboard = () => {
    const navigate = useNavigate();
    const {
        currentUser, allVehicles, allUsers, allBids, pendingVehicles, approveListing, rejectListing,
        employees, deposits, vehiclePayments, toggleUserStatus, toggleEmployeeStatus,
        overrideAuction, updateDepositStatus, addEmployee, addVehicle, logout
    } = useUser();

    const [activeTab, setActiveTab] = useState('Overview');
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const [showDirectUpload, setShowDirectUpload] = useState(false);
    const [sortConfig, setSortConfig] = useState({ key: 'endTime', direction: 'asc' });

    const handleSort = (key) => {
        let direction = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const sortedVehicles = useMemo(() => {
        const filtered = (allVehicles || [])
            .filter(v => statusFilter === 'All' || v.status === statusFilter)
            .filter(v => v.name?.toLowerCase().includes(searchTerm.toLowerCase()));

        return [...filtered].sort((a, b) => {
            if (sortConfig.key === 'endTime') {
                const timeA = new Date(a.endTime || 0).getTime();
                const timeB = new Date(b.endTime || 0).getTime();
                return sortConfig.direction === 'asc' ? timeA - timeB : timeB - timeA;
            }
            if (sortConfig.key === 'pricing') {
                const priceA = a.currentBid || a.basePrice || 0;
                const priceB = b.currentBid || b.basePrice || 0;
                return sortConfig.direction === 'asc' ? priceA - priceB : priceB - priceA;
            }
            if (sortConfig.key === 'name') {
                return sortConfig.direction === 'asc'
                    ? (a.name || '').localeCompare(b.name || '')
                    : (b.name || '').localeCompare(a.name || '');
            }
            return 0;
        });
    }, [allVehicles, searchTerm, statusFilter, sortConfig]);

    const liveAuctions = useMemo(() => {
        return (allVehicles || [])
            .filter(v => v.status === 'Live')
            .filter(v => v.name?.toLowerCase().includes(searchTerm.toLowerCase()) || v.brand?.toLowerCase().includes(searchTerm.toLowerCase()))
            .sort((a, b) => new Date(a.endTime || 0).getTime() - new Date(b.endTime || 0).getTime());
    }, [allVehicles, searchTerm]);

    if (currentUser?.role !== 'admin') {
        return (
            <div className="min-h-screen flex items-center justify-center bg-[#0f172a] p-6 text-center">
                <div className="glass-card p-12 rounded-3xl border-red-500/20 max-w-md">
                    <XCircle className="text-red-500 mx-auto mb-6" size={64} />
                    <h2 className="text-3xl font-black text-white mb-4">Access Denied</h2>
                    <p className="text-slate-500 font-medium mb-8">You do not have administrative privileges to access this control center.</p>
                    <a href="/" className="btn-primary inline-block">Return to Home</a>
                </div>
            </div>
        );
    }

    const tabs = [
        { name: 'Overview', icon: LayoutDashboard },
        { name: 'Actions', icon: ShieldAlert, count: (pendingVehicles?.length || 0) + (deposits?.filter(d => d.status === 'Pending').length || 0) },
        { name: 'Inventory', icon: Package },
        { name: 'Auctions', icon: Gavel },
        { name: 'Buyers', icon: Users },
        { name: 'Sellers', icon: UserCircle, count: (allUsers?.filter(u => u.role === 'seller').length || 0) },
        { name: 'Employees', icon: Briefcase },
        { name: 'Payments', icon: CreditCard },
        { name: 'Reports', icon: BarChart3 },
    ];

    // Helper: Stats Calculation
    const stats = useMemo(() => {
        const live = allVehicles.filter(v => v.status === 'Live').length;
        const sold = allVehicles.filter(v => v.status === 'Sold').length;
        const unsold = allVehicles.filter(v => v.status === 'Unsold').length;
        const totalRevenue = vehiclePayments.reduce((acc, p) => p.status === 'Completed' ? acc + p.amount : acc, 0);

        return {
            total: allVehicles.length,
            live,
            sold,
            unsold,
            revenue: totalRevenue,
            mtdRevenue: totalRevenue * 0.4, // Mock MTD
            buyers: allUsers.filter(u => u.role === 'buyer').length,
            sellers: allUsers.filter(u => u.role === 'seller').length,
        };
    }, [allVehicles, vehiclePayments, allUsers]);

    const ActionRequiredModule = () => (
        <div className="space-y-12 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Vehicle Approval Queue */}
                <div className="glass-card rounded-3xl p-8 border-white/5 space-y-6">
                    <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-yellow-500/10 text-yellow-500 flex items-center justify-center">
                                <Car size={20} />
                            </div>
                            <h3 className="text-xl font-black text-white">Vehicle Listings Queue</h3>
                        </div>
                        <span className="bg-slate-800 text-slate-400 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">{(pendingVehicles?.length || 0)} Pending</span>
                    </div>

                    <div className="space-y-4">
                        {pendingVehicles?.map(v => (
                            <div key={v.id} className="p-4 rounded-2xl bg-slate-900/50 border border-white/5 flex items-center gap-4 group">
                                <img src={v.images?.[0]} className="w-16 h-12 object-cover rounded-xl border border-white/5" alt="" />
                                <div className="flex-1 min-w-0">
                                    <h4 className="text-white font-bold text-sm truncate uppercase tracking-tight">{v.name}</h4>
                                    <p className="text-slate-500 text-[10px] font-medium">Seller: {allUsers?.find(u => u.id === v.sellerId)?.name || 'Unknown'}</p>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => approveListing(v.id)} className="w-10 h-10 rounded-xl bg-green-500/10 text-green-500 hover:bg-green-500 hover:text-white transition-all flex items-center justify-center">
                                        <CheckCircle2 size={18} />
                                    </button>
                                    <button onClick={() => rejectListing(v.id)} className="w-10 h-10 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all flex items-center justify-center">
                                        <XCircle size={18} />
                                    </button>
                                </div>
                            </div>
                        ))}
                        {(!pendingVehicles || pendingVehicles.length === 0) && (
                            <div className="py-12 text-center text-slate-600 space-y-3">
                                <ShieldCheck className="mx-auto" size={40} />
                                <p className="text-xs font-medium">Approval queue is clear.</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Security Deposits Checklist */}
                <div className="glass-card rounded-3xl p-8 border-white/5 space-y-6">
                    <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                                <ShieldCheck size={20} />
                            </div>
                            <h3 className="text-xl font-black text-white">Deposit Verifications</h3>
                        </div>
                        <span className="bg-slate-800 text-slate-400 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
                            {deposits?.filter(d => d.status === 'Pending').length || 0} Alert
                        </span>
                    </div>

                    <div className="space-y-4">
                        {deposits?.filter(d => d.status === 'Pending').map(d => (
                            <div key={d.id} className="p-4 rounded-2xl bg-slate-900/50 border border-white/5 flex items-center gap-4">
                                <div className="flex-1 min-w-0">
                                    <h4 className="text-white font-bold text-sm truncate">{allUsers?.find(u => u.id === d.userId)?.name}</h4>
                                    <p className="text-slate-500 text-[10px] font-medium">{d.method} • ${d.amount.toLocaleString()}</p>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => updateDepositStatus(d.id, 'Paid')} className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-emerald-500 transition-all">Verify</button>
                                </div>
                            </div>
                        ))}
                        {(!deposits || deposits.filter(d => d.status === 'Pending').length === 0) && (
                            <div className="py-12 text-center text-slate-600 space-y-3">
                                <CheckCircle2 className="mx-auto text-emerald-500" size={40} />
                                <p className="text-xs font-medium">All financial verify requests completed.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );

    // UI Modules
    const OverviewModule = () => (
        <div className="space-y-8 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard label="Live Auctions" value={stats.live} icon={Activity} color="text-green-500" bg="bg-green-500/10" />
                <StatCard label="Total Revenue" value={`$${(stats.revenue / 1000).toFixed(1)}k`} icon={TrendingUp} color="text-blue-500" bg="bg-blue-500/10" />
                <StatCard label="Vehicles Sold" value={stats.sold} icon={ShieldCheck} color="text-indigo-500" bg="bg-indigo-500/10" />
                <StatCard label="Pending Listings" value={pendingVehicles.length} icon={Clock} color="text-yellow-500" bg="bg-yellow-500/10" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="glass-card rounded-3xl p-8 border-white/5">
                    <div className="flex justify-between items-center mb-8">
                        <h3 className="text-xl font-bold text-white">Recent Auctions</h3>
                        <button onClick={() => setActiveTab('Auctions')} className="text-blue-400 font-bold text-sm hover:underline">View All</button>
                    </div>
                    <div className="space-y-4">
                        {allVehicles?.filter(v => v.status === 'Live').slice(0, 4).map(v => (
                            <Link key={v.id} to={`/vehicle/${v.id}`} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/5 transition-colors group">
                                <img src={v.images?.[0]} className="w-16 h-12 object-cover rounded-xl border border-white/5" alt="" />
                                <div className="flex-1">
                                    <h4 className="text-white font-bold group-hover:text-blue-400 transition-colors uppercase text-xs tracking-wider">{v.name}</h4>
                                    <p className="text-slate-500 text-[10px] font-black">{v.brand} • {v.fuel}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-blue-400 font-black text-sm">${(v.currentBid || 0).toLocaleString()}</p>
                                    <p className="text-slate-500 text-[10px]">Live Now</p>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>

                <div className="glass-card rounded-3xl p-8 border-white/5">
                    <div className="flex justify-between items-center mb-8">
                        <h3 className="text-xl font-bold text-white">Global Bid Stream</h3>
                        <Activity className="text-blue-500 animate-pulse" size={20} />
                    </div>
                    <div className="space-y-6">
                        {[...(allBids || [])].reverse().slice(0, 4).map(bid => {
                            const bidder = allUsers?.find(u => u.id === bid.userId);
                            return (
                                <div key={bid.id} className="flex gap-4 items-center">
                                    <img src={bidder?.avatar} className="w-10 h-10 rounded-full border border-blue-500/20" alt="" />
                                    <div className="flex-1">
                                        <p className="text-white text-xs font-medium">
                                            <span className="font-black">{bidder?.name || 'Anonymous'}</span> placed bid for <span className="text-blue-400 font-black">
                                                {allVehicles?.find(v => v.id === bid.vehicleId)?.name}
                                            </span>
                                        </p>
                                        <p className="text-slate-500 text-[10px]">{new Date(bid.timestamp).toLocaleTimeString()}</p>
                                    </div>
                                    <p className="text-white font-black">${bid.amount.toLocaleString()}</p>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );

    const InventoryModule = () => (
        <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="relative w-full md:w-96">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                    <input
                        type="text"
                        placeholder="Search inventory..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-slate-900 border border-white/5 rounded-2xl pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                    />
                </div>
                <div className="flex gap-3 w-full md:w-auto">
                    <div className="flex rounded-2xl bg-slate-900 border border-white/5 p-1">
                        {['All', 'Live', 'Sold', 'Unsold'].map(s => (
                            <button
                                key={s}
                                onClick={() => setStatusFilter(s)}
                                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${statusFilter === s ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                            >
                                {s}
                            </button>
                        ))}
                    </div>
                    <button onClick={() => setShowDirectUpload(true)} className="btn-primary flex items-center gap-2 whitespace-nowrap">
                        <Plus size={18} /> List Vehicle for Auction
                    </button>
                </div>
            </div>

            <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                <table className="w-full text-left">
                    <thead className="bg-slate-900/50 border-b border-white/5">
                        <tr>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('name')}>
                                <div className="flex items-center gap-2">
                                    Vehicle <ArrowUpDown size={12} className={sortConfig.key === 'name' ? 'text-blue-500' : 'text-slate-600'} />
                                </div>
                            </th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Type / Fuel</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('pricing')}>
                                <div className="flex items-center gap-2">
                                    Pricing <ArrowUpDown size={12} className={sortConfig.key === 'pricing' ? 'text-blue-500' : 'text-slate-600'} />
                                </div>
                            </th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('endTime')}>
                                <div className="flex items-center gap-2">
                                    Time Left <ArrowUpDown size={12} className={sortConfig.key === 'endTime' ? 'text-blue-500' : 'text-slate-600'} />
                                </div>
                            </th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                            <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {sortedVehicles.map(v => (
                            <tr key={v.id} className="hover:bg-white/5 transition-colors group">
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-4">
                                        <img src={v.images?.[0] || 'https://images.unsplash.com/photo-1503376780353-7e6692767b70'} className="w-14 h-10 object-cover rounded-xl border border-white/5" alt="" />
                                        <div>
                                            <Link to={`/vehicle/${v.id}`}>
                                                <p className="text-white font-bold group-hover:text-blue-400 transition-colors uppercase text-xs tracking-wider">{v.name || 'Unnamed Vehicle'}</p>
                                            </Link>
                                            <p className="text-slate-500 text-[10px] font-black">{v.brand || 'No Brand'} • {v.year || 'N/A'}</p>
                                        </div>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-400 text-[10px] font-bold uppercase">{v.category || 'Other'} • {v.fuel || 'Other'}</span>
                                </td>
                                <td className="px-6 py-4">
                                    <p className="text-white text-xs font-black">Bid: ${(v.currentBid || 0).toLocaleString()}</p>
                                    <p className="text-slate-500 text-[10px]">Base: ${(v.basePrice || 0).toLocaleString()}</p>
                                </td>
                                <td className="px-6 py-4">
                                    <div className="text-[10px] font-black text-blue-400">
                                        {v.status === 'Live' ? <CountdownTimer endTime={v.endTime} /> : <span className="text-slate-600">--</span>}
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <StatusBadge status={v.status} />
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="p-2 text-slate-500 hover:text-white transition-colors">
                                        <MoreVertical size={18} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {sortedVehicles.length === 0 && (
                            <tr>
                                <td colSpan="6" className="px-6 py-20 text-center">
                                    <div className="flex flex-col items-center gap-3 text-slate-500">
                                        <Package size={40} className="text-slate-700" />
                                        <p className="text-xs font-medium">No inventory found matching your criteria.</p>
                                    </div>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );

    const AuctionModule = () => (
        <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between px-2">
                <h3 className="text-xl font-bold text-white flex items-center gap-3">
                    <Activity className="text-green-500" size={24} />
                    Real-Time Auction Monitor
                </h3>
                <div className="relative w-full md:w-80">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                    <input
                        type="text"
                        placeholder="Search live auctions..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-slate-900 border border-white/5 rounded-2xl pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                    />
                </div>
            </div>
            <div className="grid grid-cols-1 gap-6">
                {liveAuctions.map(v => (
                    <div key={v.id} className="glass-card rounded-3xl p-8 border-white/5 flex flex-col md:flex-row gap-10 group overflow-hidden relative">
                        <div className="w-full md:w-64 h-48 rounded-2xl overflow-hidden">
                            <img src={v.images?.[0] || 'https://images.unsplash.com/photo-1503376780353-7e6692767b70'} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="" />
                        </div>
                        <div className="flex-1 space-y-6">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h4 className="text-2xl font-black text-white group-hover:text-blue-400 transition-colors uppercase">{v.name || 'Unnamed Vehicle'}</h4>
                                    <p className="text-slate-500 font-bold uppercase text-xs tracking-widest">{v.brand || 'No Brand'} • {v.year || 'N/A'} • {v.category || 'Other'}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-3xl font-black text-blue-500">${(v.currentBid || 0).toLocaleString()}</p>
                                    <p className="text-slate-500 text-[10px] uppercase font-black tracking-widest">Highest Bid</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-6 border-y border-white/5">
                                <AuctionMetric label="Bids" value={(allBids || []).filter(b => b.vehicleId === v.id).length} />
                                <AuctionMetric label="Time Left" value={<CountdownTimer endTime={v.endTime} />} />
                                <AuctionMetric label="Views" value="1,240" />
                                <AuctionMetric label="Seller" value={v.sellerId || 'N/A'} />
                            </div>

                            <div className="flex gap-4">
                                <button onClick={() => overrideAuction(v.id, 'Sold')} className="btn-primary px-8 flex items-center gap-2 text-xs">
                                    <CheckCircle2 size={18} /> Force End (Sold)
                                </button>
                                <button onClick={() => overrideAuction(v.id, 'Unsold')} className="px-8 py-3 rounded-xl bg-red-600/10 text-red-500 font-black text-xs uppercase hover:bg-red-600 hover:text-white transition-all">
                                    <XCircle size={18} /> Mark Unsold
                                </button>
                                <Link to={`/vehicle/${v.id}`} className="ml-auto p-4 rounded-xl bg-slate-900 border border-white/5 text-slate-500 hover:text-white transition-all">
                                    <Eye size={20} />
                                </Link>
                            </div>
                        </div>
                        <div className="absolute top-0 right-0 w-2 h-full bg-green-500 group-hover:w-4 transition-all"></div>
                    </div>
                ))}
            </div>
        </div>
    );

    const BuyersModule = () => (
        <div className="space-y-6 animate-fade-in">
            <div className="relative w-full md:w-96 px-2">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                <input
                    type="text"
                    placeholder="Search buyers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-900 border border-white/5 rounded-2xl pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                />
            </div>
            <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                <table className="w-full text-left">
                    <thead className="bg-slate-900/50 border-b border-white/5">
                        <tr>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Buyer</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Contact</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Deposit Status</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Activity</th>
                            <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {allUsers.filter(u => u.role === 'buyer' && (u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase()))).map(u => {
                            const userDeposit = deposits.find(d => d.userId === u.id);
                            return (
                                <tr key={u.id} className="hover:bg-white/5 transition-colors">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <img src={u.avatar} className="w-10 h-10 rounded-full border border-blue-500/20" alt="" />
                                            <div>
                                                <p className="text-white font-bold text-sm tracking-tight">{u.name}</p>
                                                <p className="text-slate-500 text-[10px]">ID: {u.id}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-xs text-slate-400 font-medium">{u.email}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${userDeposit?.status === 'Paid' ? 'bg-green-600/10 text-green-400' :
                                            userDeposit?.status === 'Pending' ? 'bg-yellow-600/10 text-yellow-400' : 'bg-red-600/10 text-red-500'
                                            }`}>
                                            {userDeposit?.status || 'No Deposit'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <p className="text-white text-xs font-black">{allBids.filter(b => b.userId === u.id).length} Bids</p>
                                        <p className="text-slate-500 text-[10px]">2 Purchases</p>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <button
                                            onClick={() => toggleUserStatus(u.id)}
                                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${u.status === 'Active' ? 'bg-slate-800 text-red-500 hover:bg-red-600 hover:text-white' : 'bg-green-600 text-white'
                                                }`}
                                        >
                                            {u.status === 'Active' ? 'Deactivate' : 'Activate'}
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );

    const SellersModule = () => (
        <div className="space-y-6 animate-fade-in">
            <div className="relative w-full md:w-96 px-2">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                <input
                    type="text"
                    placeholder="Search sellers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-900 border border-white/5 rounded-2xl pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                />
            </div>
            <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                <table className="w-full text-left">
                    <thead className="bg-slate-900/50 border-b border-white/5">
                        <tr>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Seller</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Contact</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Inventory</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Revenue Impact</th>
                            <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {allUsers.filter(u => u.role === 'seller' && (u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase()))).map(u => {
                            const sellerVehicles = allVehicles.filter(v => v.sellerId === u.id);
                            const totalSalesValue = allVehicles.filter(v => v.sellerId === u.id && v.status === 'Sold').reduce((acc, v) => acc + v.currentBid, 0);
                            return (
                                <tr key={u.id} className="hover:bg-white/5 transition-colors">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <img src={u.avatar} className="w-10 h-10 rounded-full border border-indigo-500/20" alt="" />
                                            <div>
                                                <p className="text-white font-bold text-sm tracking-tight">{u.name}</p>
                                                <p className="text-slate-500 text-[10px]">ID: {u.id}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-xs text-slate-400 font-medium">{u.email}</td>
                                    <td className="px-6 py-4">
                                        <p className="text-white text-xs font-black">{sellerVehicles.length} Listings</p>
                                        <p className="text-slate-500 text-[10px]">{sellerVehicles.filter(v => v.status === 'Live').length} Active</p>
                                    </td>
                                    <td className="px-6 py-4">
                                        <p className="text-indigo-400 text-xs font-black">${totalSalesValue.toLocaleString()}</p>
                                        <p className="text-slate-500 text-[10px]">Sales Volume</p>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <button
                                            onClick={() => toggleUserStatus(u.id)}
                                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${u.status === 'Active' ? 'bg-slate-800 text-red-500 hover:bg-red-600 hover:text-white' : 'bg-green-600 text-white'
                                                }`}
                                        >
                                            {u.status === 'Active' ? 'Deactivate' : 'Activate'}
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );

    const EmployeeModule = () => (
        <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6 px-4">
                <div className="relative w-full md:w-80">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                    <input
                        type="text"
                        placeholder="Search employees..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-slate-900 border border-white/5 rounded-2xl pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                    />
                </div>
                <div className="flex items-center gap-4">
                    <h3 className="text-xl font-bold text-white hidden md:block">Platform Staff</h3>
                    <button className="btn-primary flex items-center gap-2">
                        <Plus size={18} /> Add Employee
                    </button>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {employees.filter(e => e.name.toLowerCase().includes(searchTerm.toLowerCase()) || e.role.toLowerCase().includes(searchTerm.toLowerCase())).map(e => (
                    <div key={e.id} className="glass-card rounded-3xl p-6 border-white/5 relative group">
                        <div className="flex justify-between items-start mb-6">
                            <div className="w-16 h-16 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                                <Briefcase size={32} />
                            </div>
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${e.status === 'Active' ? 'bg-green-600/10 text-green-400' : 'bg-red-600/10 text-red-500'}`}>
                                {e.status}
                            </span>
                        </div>
                        <h4 className="text-xl font-bold text-white mb-1 group-hover:text-blue-400 transition-colors">{e.name}</h4>
                        <p className="text-slate-500 text-xs font-medium mb-6">{e.role} • {e.email}</p>

                        <div className="flex gap-3">
                            <button className="flex-1 px-4 py-2 rounded-xl bg-slate-900 border border-white/5 text-slate-300 text-[10px] font-black uppercase hover:bg-white/5 transition-all">Edit</button>
                            <button
                                onClick={() => toggleEmployeeStatus(e.id)}
                                className={`flex-1 px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${e.status === 'Active' ? 'bg-slate-800 text-red-500 hover:bg-red-600 hover:text-white' : 'bg-green-600 text-white'}`}>
                                {e.status === 'Active' ? 'Suspend' : 'Reinstate'}
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    const PaymentsModule = () => (
        <div className="space-y-12 animate-fade-in">
            <div className="relative w-full md:w-96 px-4">
                <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                <input
                    type="text"
                    placeholder="Search payments & ledgers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-900 border border-white/5 rounded-2xl pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                />
            </div>
            <div className="space-y-6">
                <h3 className="text-xl font-bold text-white flex items-center gap-3 px-4">
                    <ArrowDownLeft className="text-green-500" size={24} />
                    Buyer Deposits
                </h3>
                <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                    <table className="w-full text-left">
                        <thead className="bg-slate-900/50 border-b border-white/5">
                            <tr>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Buyer</th>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Amount</th>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Method</th>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                                <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Date</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                            {deposits.filter(d => {
                                const buyerName = allUsers.find(u => u.id === d.userId)?.name || '';
                                return buyerName.toLowerCase().includes(searchTerm.toLowerCase()) || d.method.toLowerCase().includes(searchTerm.toLowerCase());
                            }).map(d => (
                                <tr key={d.id} className="hover:bg-white/5 transition-colors">
                                    <td className="px-6 py-4 text-white font-bold text-sm tracking-tight">{allUsers.find(u => u.id === d.userId)?.name}</td>
                                    <td className="px-6 py-4 text-white font-black">${d.amount.toLocaleString()}</td>
                                    <td className="px-6 py-4 text-slate-500 text-xs font-medium">{d.method}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${d.status === 'Paid' ? 'bg-green-600/10 text-green-400' : 'bg-slate-800 text-slate-500'
                                            }`}>{d.status}</span>
                                    </td>
                                    <td className="px-6 py-4 text-right text-slate-500 text-[10px] font-bold">{d.date}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            <div className="space-y-6">
                <h3 className="text-xl font-bold text-white flex items-center gap-3 px-4">
                    <ArrowUpRight className="text-blue-500" size={24} />
                    Vehicle Transaction Ledger
                </h3>
                <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                    <table className="w-full text-left">
                        <thead className="bg-slate-900/50 border-b border-white/5">
                            <tr>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Asset</th>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Settlement</th>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">REF ID</th>
                                <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                                <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Date</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                            {vehiclePayments.filter(p => {
                                const vehicleName = allVehicles.find(v => v.id === p.vehicleId)?.name || '';
                                const buyerName = allUsers.find(u => u.id === p.userId)?.name || '';
                                return vehicleName.toLowerCase().includes(searchTerm.toLowerCase()) || buyerName.toLowerCase().includes(searchTerm.toLowerCase()) || p.id.toLowerCase().includes(searchTerm.toLowerCase());
                            }).map(p => (
                                <tr key={p.id} className="hover:bg-white/5 transition-colors">
                                    <td className="px-6 py-4">
                                        <p className="text-white font-bold text-sm tracking-tight">{allVehicles.find(v => v.id === p.vehicleId)?.name}</p>
                                        <p className="text-slate-500 text-[10px] uppercase font-black">Buyer: {allUsers.find(u => u.id === p.userId)?.name}</p>
                                    </td>
                                    <td className="px-6 py-4 text-blue-400 font-black">${p.amount.toLocaleString()}</td>
                                    <td className="px-6 py-4 text-slate-500 text-[10px] font-black">{p.ref}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${p.status === 'Completed' ? 'bg-green-600/10 text-green-400' : 'bg-yellow-600/10 text-yellow-400'
                                            }`}>{p.status}</span>
                                    </td>
                                    <td className="px-6 py-4 text-right text-slate-500 text-[10px] font-bold">{p.date}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );

    // Chart Components
    const DonutChart = ({ data }) => {
        const total = data.reduce((acc, item) => acc + item.value, 0);
        let cumulativePercent = 0;

        const getCoordinatesForPercent = (percent) => {
            const x = Math.cos(2 * Math.PI * percent);
            const y = Math.sin(2 * Math.PI * percent);
            return [x, y];
        };

        return (
            <div className="relative w-48 h-48 mx-auto">
                <svg viewBox="-1 -1 2 2" className="transform -rotate-90 w-full h-full">
                    {data.map((item, i) => {
                        const [startX, startY] = getCoordinatesForPercent(cumulativePercent);
                        cumulativePercent += item.value / total;
                        const [endX, endY] = getCoordinatesForPercent(cumulativePercent);
                        const largeArcFlag = item.value / total > 0.5 ? 1 : 0;
                        const pathData = [
                            `M ${startX} ${startY}`,
                            `A 1 1 0 ${largeArcFlag} 1 ${endX} ${endY}`,
                            `L 0 0`,
                        ].join(' ');

                        return (
                            <path
                                key={i}
                                d={pathData}
                                fill={item.color}
                                className="transition-all duration-1000 opacity-80 hover:opacity-100 cursor-pointer"
                            >
                                <title>{item.name}: {item.value}</title>
                            </path>
                        );
                    })}
                    <circle r="0.7" fill="#0f172a" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <p className="text-2xl font-black text-white">{total}</p>
                    <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest">Total Ads</p>
                </div>
            </div>
        );
    };

    const BarChart = ({ data }) => {
        const max = Math.max(...data.map(d => d.value), 1);
        return (
            <div className="h-64 flex items-end justify-between gap-4 px-2">
                {data.map((item, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-4 group">
                        <div className="w-full relative flex flex-col justify-end h-48 bg-white/5 rounded-2xl overflow-hidden">
                            <div
                                className="w-full bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-xl transition-all duration-1000 ease-out delay-[${i * 100}ms]"
                                style={{ height: `${(item.value / max) * 100}%` }}
                            >
                                <div className="absolute top-2 left-0 right-0 text-center text-[10px] font-black text-white opacity-0 group-hover:opacity-100 transition-opacity">
                                    {item.value}
                                </div>
                            </div>
                        </div>
                        <p className="text-[8px] font-black text-slate-500 uppercase tracking-tighter truncate w-full text-center">{item.name}</p>
                    </div>
                ))}
            </div>
        );
    };

    const ReportsModule = () => {
        const categories = ['SUV', 'Sedan', 'Sport', 'Luxury', 'Electric'];
        const categoryData = categories.map((cat, i) => ({
            name: cat,
            value: allVehicles.filter(v => v.category === cat).length || Math.floor(Math.random() * 20) + 5,
            color: ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'][i]
        }));

        const salesByCategory = categories.map(cat => ({
            name: cat,
            value: allVehicles.filter(v => v.category === cat && v.status === 'Sold').length || Math.floor(Math.random() * 10) + 2
        }));

        return (
            <div className="space-y-12 animate-fade-in pb-20">
                <div className="flex justify-between items-center px-4">
                    <div>
                        <h3 className="text-2xl font-black text-white">Business Intelligence</h3>
                        <p className="text-slate-500 text-xs font-medium">Real-time performance analytics and market trends</p>
                    </div>
                    <button className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-white/5 text-white font-bold text-sm hover:bg-white/10 transition-all border border-white/5">
                        <Download size={18} /> Export Performance Data
                    </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Inventory Overview (Donut) */}
                    <div className="glass-card rounded-3xl p-8 border-white/5">
                        <div className="flex justify-between items-start mb-10">
                            <div>
                                <h4 className="text-white font-bold text-sm mb-1">Stock Distribution</h4>
                                <p className="text-slate-500 text-[10px] font-medium">Inventory share by category</p>
                            </div>
                            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-500">
                                <Package size={18} />
                            </div>
                        </div>
                        <DonutChart data={categoryData} />
                        <div className="mt-10 grid grid-cols-2 gap-4">
                            {categoryData.map((item, i) => (
                                <div key={i} className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></div>
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{item.name}</span>
                                    <span className="ml-auto text-[10px] font-black text-white">{item.value}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Sales Performance (Bar) */}
                    <div className="glass-card rounded-3xl p-8 border-white/5 lg:col-span-2">
                        <div className="flex justify-between items-start mb-10">
                            <div>
                                <h4 className="text-white font-bold text-sm mb-1">Sales Velocity</h4>
                                <p className="text-slate-500 text-[10px] font-medium">Completed auctions by category</p>
                            </div>
                            <div className="flex gap-2">
                                <span className="px-3 py-1 rounded-lg bg-blue-500/10 text-blue-500 text-[10px] font-bold cursor-pointer">Units</span>
                                <span className="px-3 py-1 rounded-lg bg-white/5 text-slate-500 text-[10px] font-bold cursor-pointer">Revenue</span>
                            </div>
                        </div>
                        <BarChart data={salesByCategory} />
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Inventory Clearance */}
                    <div className="glass-card rounded-3xl p-8 border-white/5">
                        <h4 className="text-white font-bold text-sm mb-8">Inventory Clearance</h4>
                        <div className="h-64 flex items-end gap-12 px-6">
                            <div className="flex-1 flex flex-col items-center gap-4 group">
                                <div className="w-full relative h-48 bg-green-500/5 rounded-2xl overflow-hidden border border-green-500/10">
                                    <div
                                        className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-green-600 to-green-400 rounded-t-xl transition-all duration-[1500ms] ease-out shadow-[0_0_20px_rgba(34,197,94,0.3)]"
                                        style={{ height: `${(stats.sold / (stats.sold + stats.unsold || 1)) * 100}%` }}
                                    >
                                    </div>
                                </div>
                                <div className="text-center">
                                    <p className="text-[10px] font-black text-white">{stats.sold}</p>
                                    <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Units Sold</p>
                                </div>
                            </div>
                            <div className="flex-1 flex flex-col items-center gap-4 group">
                                <div className="w-full relative h-48 bg-red-500/5 rounded-2xl overflow-hidden border border-red-500/10">
                                    <div
                                        className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-red-600 to-red-400 rounded-t-xl transition-all duration-[1500ms] ease-out shadow-[0_0_20px_rgba(239,68,68,0.3)]"
                                        style={{ height: `${(stats.unsold / (stats.sold + stats.unsold || 1)) * 100}%` }}
                                    >
                                    </div>
                                </div>
                                <div className="text-center">
                                    <p className="text-[10px] font-black text-white">{stats.unsold}</p>
                                    <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Unsold</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Performance Metrics */}
                    <div className="glass-card rounded-3xl p-8 border-white/5">
                        <h4 className="text-white font-bold text-sm mb-8">Performance Summary</h4>
                        <div className="space-y-8">
                            <div className="flex items-center justify-between p-6 rounded-2xl bg-white/5 border border-white/5">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-blue-500 flex items-center justify-center">
                                        <TrendingUp size={24} />
                                    </div>
                                    <div>
                                        <p className="text-white font-bold">MTD Revenue</p>
                                        <p className="text-slate-500 text-[10px] font-medium">Growth vs last month</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-xl font-black text-white">${(stats.mtdRevenue / 1000).toFixed(1)}k</p>
                                    <p className="text-green-500 text-[10px] font-bold">+12.4%</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-6">
                                <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
                                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">New Buyers</p>
                                    <p className="text-2xl font-black text-white">+86</p>
                                    <div className="mt-4 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '80%' }}></div>
                                    </div>
                                </div>
                                <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
                                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">Inventory Velocity</p>
                                    <p className="text-2xl font-black text-white">4.2d</p>
                                    <div className="mt-4 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                                        <div className="h-full bg-indigo-500 rounded-full" style={{ width: '65%' }}></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="flex min-h-screen bg-[#0f172a]">
            {/* Sidebar */}
            <aside className="w-72 bg-slate-900 border-r border-white/5 hidden lg:flex flex-col p-6 pt-24 space-y-10 fixed top-0 left-0 h-full z-[70]">
                <div>
                    <h2 className="text-3xl font-black text-white px-2">Admin<span className="text-blue-500">.</span></h2>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] px-2.5">Auction Management</p>
                </div>

                <nav className="flex-1 flex flex-col gap-2">
                    {tabs.map(tab => (
                        <button
                            key={tab.name}
                            onClick={() => setActiveTab(tab.name)}
                            className={`flex items-center gap-4 px-4 py-4 rounded-2xl font-bold transition-all duration-300 ${activeTab === tab.name
                                ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20'
                                : 'text-slate-500 hover:text-white hover:bg-white/5'
                                }`}
                        >
                            <tab.icon size={20} />
                            <span className="text-sm">{tab.name}</span>
                            {tab.count > 0 && <span className="ml-auto text-[10px] bg-white/10 px-2 py-0.5 rounded-full">{tab.count}</span>}
                            {activeTab === tab.name && !tab.count && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>}
                        </button>
                    ))}
                </nav>

                <div className="glass-card p-6 bg-slate-800/20 border-white/5 rounded-3xl">
                    <ShieldCheck className="text-blue-500 mb-4" size={24} />
                    <h4 className="text-white font-bold text-xs mb-1">Audit Mode</h4>
                    <p className="text-slate-500 text-[10px] leading-tight font-medium">Session token access granted.</p>
                </div>

                <button
                    onClick={() => { logout(); navigate('/'); }}
                    className="flex items-center gap-4 px-4 py-4 rounded-2xl font-bold text-red-500 hover:bg-red-500/10 transition-all border border-transparent hover:border-red-500/20"
                >
                    <LogOut size={20} />
                    <span className="text-sm">Log Out</span>
                </button>
            </aside>

            {/* Main Content */}
            <main className="flex-1 lg:ml-72 bg-[#0f172a] min-h-screen p-6 md:p-12">
                <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8 mt-4">
                    <div>
                        <div className="flex items-center gap-3 text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">
                            <span>Admin Portal</span>
                            <ChevronRight size={14} />
                            <span className="text-blue-500">{activeTab} Management</span>
                        </div>
                        <h1 className="text-4xl font-black text-white">{activeTab}</h1>
                    </div>
                    <div className="flex items-center gap-6">
                        <div className="text-right hidden sm:block">
                            <p className="text-white font-bold tracking-tight">DriveBid HQ</p>
                            <p className="text-emerald-500 text-[10px] font-black uppercase flex items-center justify-end gap-1.5 tracking-tighter">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> System Operational
                            </p>
                        </div>
                        <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-white/5 flex items-center justify-center text-white cursor-pointer hover:bg-slate-700 transition-all">
                            <Users size={20} />
                        </div>
                    </div>
                </header>

                <div className="min-h-screen">
                    {activeTab === 'Overview' && <OverviewModule />}
                    {activeTab === 'Inventory' && <InventoryModule />}
                    {activeTab === 'Auctions' && <AuctionModule />}
                    {activeTab === 'Buyers' && <BuyersModule />}
                    {activeTab === 'Employees' && <EmployeeModule />}
                    {activeTab === 'Payments' && <PaymentsModule />}
                    {activeTab === 'Reports' && <ReportsModule />}
                    {activeTab === 'Sellers' && <SellersModule />}
                    {activeTab === 'Actions' && <ActionRequiredModule />}
                </div>
            </main>

            {/* Approval Notification Overlay */}
            {pendingVehicles.length > 0 && activeTab === 'Overview' && (
                <div className="fixed bottom-10 right-10 z-[100] glass-card p-6 border-blue-500/20 bg-blue-500/5 rounded-3xl w-96 animate-in slide-in-from-bottom-10">
                    <div className="flex items-center gap-4 mb-4">
                        <Clock className="text-blue-500" />
                        <h4 className="text-white font-bold">Action Required</h4>
                        <span className="ml-auto bg-blue-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full">{pendingVehicles.length}</span>
                    </div>
                    <p className="text-slate-400 text-xs mb-6 font-medium">There are new vehicle listings waiting for your approval to go live.</p>
                    <div className="space-y-3">
                        {pendingVehicles.slice(0, 2).map(v => (
                            <div key={v.id} className="flex items-center justify-between p-3 rounded-2xl bg-slate-900 border border-white/5">
                                <span className="text-white text-[10px] font-bold uppercase truncate pr-4">{v.name}</span>
                                <div className="flex gap-2">
                                    <button onClick={() => approveListing(v.id)} className="p-1.5 rounded-lg bg-green-500/20 text-green-500 hover:bg-green-500 hover:text-white transition-all">
                                        <CheckCircle2 size={16} />
                                    </button>
                                    <button onClick={() => rejectListing(v.id)} className="p-1.5 rounded-lg bg-red-500/20 text-red-500 hover:bg-red-600 hover:text-white transition-all">
                                        <XCircle size={16} />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

// Helper Components
const StatCard = ({ label, value, icon: Icon, color, bg }) => (
    <div className="glass-card rounded-3xl p-8 border-white/5 relative group overflow-hidden transition-all duration-500 hover:translate-y-[-4px]">
        <div className={`w-14 h-14 ${bg} ${color} rounded-2xl flex items-center justify-center mb-6`}>
            <Icon size={28} />
        </div>
        <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mb-2">{label}</p>
        <p className="text-4xl font-black text-white">{value}</p>
        <div className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full bg-white/[0.02] group-hover:scale-150 transition-transform duration-700"></div>
    </div>
);

const AuctionMetric = ({ label, value }) => (
    <div>
        <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">{label}</p>
        <p className="text-white font-bold">{value}</p>
    </div>
);

const StatusBadge = ({ status }) => {
    const styles = {
        Live: 'bg-green-600/10 text-green-400 border-green-600/20',
        Sold: 'bg-blue-600/10 text-blue-400 border-blue-600/20',
        Unsold: 'bg-red-600/10 text-red-500 border-red-600/20'
    };
    return (
        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter border ${styles[status] || 'bg-slate-700/30 text-slate-400 border-white/5'}`}>
            {status}
        </span>
    );
};

const ChartMini = ({ label, value, percent }) => (
    <div className="space-y-3">
        <div className="flex justify-between items-end">
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">{label}</p>
            <p className="text-white font-black text-sm">{value}</p>
        </div>
        <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 rounded-full" style={{ width: `${percent}%` }}></div>
        </div>
    </div>
);

export default AdminDashboard;
