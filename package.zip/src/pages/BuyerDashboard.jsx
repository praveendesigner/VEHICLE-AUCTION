import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { Link, useNavigate } from 'react-router-dom';
import {
    User, Car, CreditCard, ShieldCheck, FileText, Settings,
    ChevronRight, LogOut, Package, Gavel, Timer, CheckCircle2,
    Clock, Bell, Camera, UserCircle, Mail, Phone, Hash, Upload, Download, Trash2, Eye, LayoutGrid, CloudUpload, Activity, History
} from 'lucide-react';
import CountdownTimer from '../components/CountdownTimer';

const BuyerDashboard = () => {
    const navigate = useNavigate();
    const {
        currentUser, allVehicles, allBids, notifications,
        vehiclePayments, deposits, userDocuments,
        updateProfile, uploadDocument, logout
    } = useUser();

    const [activeSection, setActiveSection] = useState('Overview');
    const [isEditingProfile, setIsEditingProfile] = useState(false);
    const [profileData, setProfileData] = useState({
        name: currentUser?.name || '',
        email: currentUser?.email || '',
        mobile: currentUser?.mobile || ''
    });

    const userBids = allBids.filter(b => b.userId === currentUser?.id);
    const userBidVehicleIds = [...new Set(userBids.map(b => b.vehicleId))];
    const participatedVehicles = allVehicles.filter(v => userBidVehicleIds.includes(v.id));

    const activeBids = participatedVehicles.filter(v => v.status === 'Live');
    const wonAuctions = allVehicles.filter(v =>
        v.status === 'Sold' &&
        allBids.filter(b => b.vehicleId === v.id).sort((a, b) => b.amount - a.amount)[0]?.userId === currentUser?.id
    );
    const awaitingConfirmation = participatedVehicles.filter(v =>
        v.status === 'Ended' &&
        allBids.filter(b => b.vehicleId === v.id).sort((a, b) => b.amount - a.amount)[0]?.userId === currentUser?.id &&
        !vehiclePayments.find(p => p.vehicleId === v.id && p.status === 'Completed')
    );

    const [vehicleTab, setVehicleTab] = useState('Active');
    const vehicleTabs = [
        { id: 'Active', label: 'Active Bids', count: activeBids.length, icon: Gavel },
        { id: 'Won', label: 'Won Auctions', count: wonAuctions.length, icon: CheckCircle2 },
        { id: 'Pending', label: 'Awaiting Confirm', count: awaitingConfirmation.length, icon: Clock },
        { id: 'History', label: 'Participated', count: participatedVehicles.length, icon: History }
    ];

    const menuItems = [
        { id: 'Overview', icon: LayoutGrid, label: 'Overview' },
        { id: 'Profile', icon: UserCircle, label: 'My Profile' },
        { id: 'Vehicles', icon: Car, label: 'My Vehicles' },
        { id: 'Payments', icon: CreditCard, label: 'My Payments' },
        { id: 'Deposits', icon: ShieldCheck, label: 'Security Deposits' },
        { id: 'Documents', icon: FileText, label: 'My Documents' },
    ];

    const handleProfileUpdate = (e) => {
        e.preventDefault();
        updateProfile(currentUser.id, profileData);
        setIsEditingProfile(false);
    };

    const handleDocUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                uploadDocument({
                    name: file.name,
                    type: file.type,
                    size: (file.size / 1024).toFixed(2) + ' KB',
                    data: reader.result
                });
            };
            reader.readAsDataURL(file);
        }
    };


    return (
        <div className="min-h-screen bg-[#0f172a] flex flex-col lg:flex-row">
            {/* Sidebar Navigation */}
            <aside className="w-full lg:w-72 bg-slate-900 border-r border-white/5 flex flex-col p-6 lg:pt-28 space-y-10 lg:fixed lg:top-0 lg:left-0 lg:h-full z-[60]">
                <div className="flex items-center gap-4 px-2">
                    <img src={currentUser?.avatar} className="w-12 h-12 rounded-2xl border border-blue-500/20" alt="" />
                    <div>
                        <h2 className="text-white font-black text-sm">{currentUser?.name}</h2>
                        <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">{currentUser?.role}</p>
                    </div>
                </div>

                <nav className="flex-1 space-y-2">
                    {menuItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => setActiveSection(item.id)}
                            className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl font-bold transition-all duration-300 ${activeSection === item.id
                                ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20'
                                : 'text-slate-500 hover:text-white hover:bg-white/5'
                                }`}
                        >
                            <item.icon size={20} />
                            <span className="text-sm">{item.label}</span>
                            {activeSection === item.id && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>}
                        </button>
                    ))}
                </nav>

                <button
                    onClick={() => { logout(); navigate('/'); }}
                    className="flex items-center gap-4 px-4 py-4 rounded-2xl font-bold text-red-500 hover:bg-red-500/10 transition-all border border-transparent hover:border-red-500/20"
                >
                    <LogOut size={20} />
                    <span className="text-sm text-red-500">Log Out</span>
                </button>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 lg:ml-72 p-6 md:p-12">
                <header className="mb-12">
                    <div className="flex items-center gap-3 text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">
                        <span>Buyer Dashboard</span>
                        <ChevronRight size={14} />
                        <span className="text-blue-500">{activeSection}</span>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-black text-white">{activeSection}</h1>
                </header>

                {/* Section Content */}
                <div className="animate-fade-in">
                    {activeSection === 'Overview' && (
                        <div className="space-y-10">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                <SummaryCard label="Won Auctions" value={wonAuctions.length} icon={Package} color="text-green-500" bg="bg-green-500/10" />
                                <SummaryCard label="Active Bids" value={activeBids.length} icon={Gavel} color="text-blue-500" bg="bg-blue-500/10" />
                                <SummaryCard label="Deposits" value={`$${deposits.filter(d => d.userId === currentUser.id).reduce((acc, d) => acc + d.amount, 0).toLocaleString()}`} icon={ShieldCheck} color="text-indigo-500" bg="bg-indigo-500/10" />
                                <SummaryCard label="Total Spent" value={`$${vehiclePayments.filter(p => p.userId === currentUser.id && p.status === 'Completed').reduce((acc, p) => acc + p.amount, 0).toLocaleString()}`} icon={CreditCard} color="text-emerald-500" bg="bg-emerald-500/10" />
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                <div className="glass-card rounded-3xl p-8 border-white/5">
                                    <h3 className="text-xl font-bold text-white mb-6">Recent Activity</h3>
                                    <div className="space-y-6">
                                        {userBids.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 4).map(bid => {
                                            const v = allVehicles.find(v => v.id === bid.vehicleId);
                                            return (
                                                <div key={bid.id} className="flex gap-4 items-center">
                                                    <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-blue-500">
                                                        <Gavel size={20} />
                                                    </div>
                                                    <div className="flex-1">
                                                        <p className="text-white text-xs font-medium">Bidded <span className="text-blue-400 font-bold">${bid.amount.toLocaleString()}</span> for {v?.name}</p>
                                                        <p className="text-slate-500 text-[10px]">{new Date(bid.timestamp).toLocaleString()}</p>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeSection === 'Profile' && (
                        <div className="max-w-3xl">
                            <div className="glass-card rounded-3xl p-10 border-white/5 space-y-10">
                                <div className="flex flex-col md:flex-row items-center gap-10 border-b border-white/5 pb-10">
                                    <div className="relative group">
                                        <img src={currentUser?.avatar} className="w-32 h-32 rounded-3xl border-2 border-blue-500/20" alt="" />
                                        <button className="absolute -bottom-2 -right-2 bg-blue-600 p-3 rounded-2xl text-white shadow-xl hover:scale-110 transition-transform">
                                            <Camera size={20} />
                                        </button>
                                    </div>
                                    <div className="flex-1 text-center md:text-left space-y-2">
                                        <h2 className="text-3xl font-black text-white">{currentUser?.name}</h2>
                                        <p className="text-slate-500 font-bold flex items-center justify-center md:justify-start gap-2">
                                            <Hash size={14} className="text-blue-500" />
                                            Member ID: <span className="text-blue-400">{currentUser?.id}</span>
                                        </p>
                                    </div>
                                    <button
                                        onClick={() => setIsEditingProfile(!isEditingProfile)}
                                        className="btn-primary px-8"
                                    >
                                        {isEditingProfile ? 'Cancel' : 'Edit Profile'}
                                    </button>
                                </div>

                                {isEditingProfile ? (
                                    <form onSubmit={handleProfileUpdate} className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                        <ProfileInput
                                            label="Full Name"
                                            value={profileData.name}
                                            onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                                            icon={User}
                                        />
                                        <ProfileInput
                                            label="Email Address"
                                            value={profileData.email}
                                            onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                                            icon={Mail}
                                            type="email"
                                        />
                                        <ProfileInput
                                            label="Mobile Number"
                                            value={profileData.mobile}
                                            onChange={(e) => setProfileData({ ...profileData, mobile: e.target.value })}
                                            icon={Phone}
                                        />
                                        <div className="md:col-span-2 pt-4">
                                            <button type="submit" className="btn-primary w-full py-4 text-sm tracking-widest uppercase font-black">Save Profile Changes</button>
                                        </div>
                                    </form>
                                ) : (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                        <ProfileData label="Registered Name" value={currentUser?.name} icon={User} />
                                        <ProfileData label="User ID" value={currentUser?.id} icon={Hash} />
                                        <ProfileData label="Email Address" value={currentUser?.email} icon={Mail} />
                                        <ProfileData label="Mobile Number" value={currentUser?.mobile || '+1 234 567 890'} icon={Phone} />
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {activeSection === 'Vehicles' && (
                        <div className="space-y-8">
                            {/* Sub-tabs for Buyer Vehicles */}
                            <div className="flex border-b border-white/5 pb-2 gap-8 overflow-x-auto no-scrollbar">
                                {vehicleTabs.map(tab => (
                                    <button
                                        key={tab.id}
                                        onClick={() => setVehicleTab(tab.id)}
                                        className={`relative pb-2 flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] transition-all ${vehicleTab === tab.id ? 'text-blue-500' : 'text-slate-500 hover:text-white'}`}
                                    >
                                        <tab.icon size={14} />
                                        {tab.label}
                                        <span className={`ml-1 px-2 py-0.5 rounded-full text-[8px] ${vehicleTab === tab.id ? 'bg-blue-500/10 text-blue-400' : 'bg-slate-800 text-slate-500'}`}>
                                            {tab.count}
                                        </span>
                                        {vehicleTab === tab.id && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>}
                                    </button>
                                ))}
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
                                {vehicleTab === 'Active' && (
                                    <>
                                        {activeBids.map(v => {
                                            const bidsForV = allBids.filter(b => b.vehicleId === v.id);
                                            const myHighest = Math.max(...bidsForV.filter(b => b.userId === currentUser?.id).map(b => b.amount));
                                            const currentHighest = Math.max(...bidsForV.map(b => b.amount));
                                            const isWinning = myHighest === currentHighest;
                                            return (
                                                <VehicleDashCard
                                                    key={v.id}
                                                    vehicle={v}
                                                    status={isWinning ? 'Winning' : 'Outbid'}
                                                    showTimer
                                                    myBid={myHighest}
                                                />
                                            );
                                        })}
                                        {activeBids.length === 0 && <EmptyState message="You have no active bids at the moment." />}
                                    </>
                                )}

                                {vehicleTab === 'Won' && (
                                    <>
                                        {wonAuctions.map(v => (
                                            <VehicleDashCard key={v.id} vehicle={v} status="Purchased" />
                                        ))}
                                        {wonAuctions.length === 0 && <EmptyState message="You haven't won any auctions yet." />}
                                    </>
                                )}

                                {vehicleTab === 'Pending' && (
                                    <>
                                        {awaitingConfirmation.map(v => (
                                            <VehicleDashCard key={v.id} vehicle={v} status="Pending Confirm" />
                                        ))}
                                        {awaitingConfirmation.length === 0 && <EmptyState message="No auctions awaiting confirmation." />}
                                    </>
                                )}

                                {vehicleTab === 'History' && (
                                    <>
                                        {participatedVehicles.map(v => {
                                            const bidsForV = allBids.filter(b => b.vehicleId === v.id);
                                            const myHighest = Math.max(...bidsForV.filter(b => b.userId === currentUser?.id).map(b => b.amount));
                                            const currentHighest = Math.max(...bidsForV.map(b => b.amount));
                                            const isWinning = v.status === 'Live' ? (myHighest === currentHighest) : (v.status === 'Sold' && myHighest === v.currentBid);

                                            let displayStatus = v.status;
                                            if (v.status === 'Live') displayStatus = isWinning ? 'Winning' : 'Outbid';
                                            if (v.status === 'Sold') displayStatus = isWinning ? 'Won' : 'Missed';
                                            if (v.status === 'Ended') displayStatus = 'Ended';

                                            return (
                                                <VehicleDashCard
                                                    key={v.id}
                                                    vehicle={v}
                                                    status={displayStatus}
                                                    myBid={myHighest}
                                                />
                                            );
                                        })}
                                        {participatedVehicles.length === 0 && <EmptyState message="You haven't participated in any auctions yet." />}
                                    </>
                                )}
                            </div>
                        </div>
                    )}

                    {activeSection === 'Payments' && (
                        <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                            <table className="w-full text-left">
                                <thead className="bg-slate-900/50 border-b border-white/5">
                                    <tr>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Asset</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Amount</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Date</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Method</th>
                                        <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {vehiclePayments.filter(p => p.userId === currentUser.id).map(p => (
                                        <tr key={p.id} className="hover:bg-white/5 transition-colors">
                                            <td className="px-6 py-4">
                                                <p className="text-white font-bold text-sm">{allVehicles.find(v => v.id === p.vehicleId)?.name}</p>
                                                <p className="text-slate-500 text-[10px]">ID: {p.ref}</p>
                                            </td>
                                            <td className="px-6 py-4 text-white font-black">${p.amount.toLocaleString()}</td>
                                            <td className="px-6 py-4 text-slate-500 text-xs font-medium">{p.date}</td>
                                            <td className="px-6 py-4 text-slate-500 text-xs font-medium">{p.method}</td>
                                            <td className="px-6 py-4 text-right">
                                                <StatusBadge status={p.status} />
                                            </td>
                                        </tr>
                                    ))}
                                    {vehiclePayments.filter(p => p.userId === currentUser.id).length === 0 && (
                                        <tr><td colSpan="5" className="px-6 py-20 text-center text-slate-600">No payment records found.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {activeSection === 'Deposits' && (
                        <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                            <table className="w-full text-left">
                                <thead className="bg-slate-900/50 border-b border-white/5">
                                    <tr>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Transaction ID</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Deposit Amount</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Reference</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Date</th>
                                        <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {deposits.filter(d => d.userId === currentUser.id).map(d => (
                                        <tr key={d.id} className="hover:bg-white/5 transition-colors">
                                            <td className="px-6 py-4 text-white font-bold text-xs">{d.id}</td>
                                            <td className="px-6 py-4 text-blue-400 font-black">${d.amount.toLocaleString()}</td>
                                            <td className="px-6 py-4 text-slate-500 text-xs font-medium">{d.method}</td>
                                            <td className="px-6 py-4 text-slate-500 text-xs font-medium">{d.date}</td>
                                            <td className="px-6 py-4 text-right">
                                                <StatusBadge status={d.status} />
                                            </td>
                                        </tr>
                                    ))}
                                    {deposits.filter(d => d.userId === currentUser.id).length === 0 && (
                                        <tr><td colSpan="5" className="px-6 py-20 text-center text-slate-600">No security deposits found.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {activeSection === 'Documents' && (
                        <div className="space-y-8">
                            <div className="glass-card rounded-3xl p-10 border-white/5 flex flex-col items-center justify-center text-center space-y-4">
                                <div className="bg-blue-600/10 w-20 h-20 rounded-3xl flex items-center justify-center text-blue-500">
                                    <CloudUpload size={40} />
                                </div>
                                <div>
                                    <h3 className="text-xl font-bold text-white">Upload New Document</h3>
                                    <p className="text-slate-500 text-sm max-w-sm">Keep your KYC and auction-related documents secure and organized.</p>
                                </div>
                                <input type="file" id="doc-upload" className="hidden" onChange={handleDocUpload} />
                                <label htmlFor="doc-upload" className="btn-primary cursor-pointer px-10 flex items-center gap-3">
                                    <Upload size={18} /> Upload Files
                                </label>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {userDocuments.filter(doc => doc.userId === currentUser.id).map(doc => (
                                    <div key={doc.id} className="glass-card rounded-2xl p-6 border-white/5 hover:border-blue-500/20 transition-all group relative">
                                        <div className="flex items-start gap-4 mb-4">
                                            <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-blue-400">
                                                <FileText size={24} />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h4 className="text-white font-bold text-sm truncate">{doc.name}</h4>
                                                <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">{doc.size} • {new Date(doc.timestamp).toLocaleDateString()}</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-2">
                                            <button className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-all text-[10px] font-black uppercase flex items-center justify-center gap-2">
                                                <Download size={12} /> Download
                                            </button>
                                            <button className="w-10 h-10 rounded-lg bg-red-900/20 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all">
                                                <Trash2 size={16} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

// Helper Components
const SummaryCard = ({ label, value, icon: Icon, color, bg }) => (
    <div className="glass-card rounded-3xl p-8 border-white/5 relative group overflow-hidden transition-all duration-500 hover:translate-y-[-4px]">
        <div className={`w-14 h-14 ${bg} ${color} rounded-2xl flex items-center justify-center mb-6`}>
            <Icon size={28} />
        </div>
        <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mb-2">{label}</p>
        <p className="text-4xl font-black text-white">{value}</p>
        <div className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full bg-white/[0.02] group-hover:scale-150 transition-transform duration-700"></div>
    </div>
);

const ProfileInput = ({ label, value, onChange, icon: Icon, type = 'text' }) => (
    <div className="space-y-2">
        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">{label}</label>
        <div className="relative">
            <Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input
                type={type}
                required
                value={value}
                onChange={onChange}
                className="w-full bg-slate-900 border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
            />
        </div>
    </div>
);

const ProfileData = ({ label, value, icon: Icon }) => (
    <div className="flex gap-6 items-center">
        <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-blue-500">
            <Icon size={24} />
        </div>
        <div>
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">{label}</p>
            <p className="text-white font-bold">{value || '--'}</p>
        </div>
    </div>
);

const VehicleDashCard = ({ vehicle, status, showTimer, myBid }) => (
    <div className="glass-card rounded-3xl p-6 border-white/5 flex flex-col sm:flex-row gap-6 hover:border-white/10 transition-all group overflow-hidden relative">
        <div className="w-full sm:w-40 h-32 rounded-2xl overflow-hidden shrink-0">
            <img src={vehicle.images[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" />
        </div>
        <div className="flex-1 min-w-0 space-y-4">
            <div>
                <h4 className="text-xl font-bold text-white truncate mb-1">{vehicle.name}</h4>
                <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">{vehicle.brand} • {vehicle.year}</p>
            </div>
            <div className="flex flex-wrap gap-4">
                <div className="bg-slate-900/50 px-4 py-2 rounded-xl border border-white/5">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">{myBid ? 'My Bid' : 'Price'}</p>
                    <p className="text-white font-black text-sm">${(myBid || vehicle.currentBid).toLocaleString()}</p>
                </div>
                {showTimer && (
                    <div className="bg-blue-500/5 px-4 py-2 rounded-xl border border-blue-500/10">
                        <p className="text-[10px] text-blue-400/70 font-bold uppercase mb-1">Time Left</p>
                        <div className="text-blue-400 font-black text-sm">
                            <CountdownTimer endTime={vehicle.endTime} />
                        </div>
                    </div>
                )}
            </div>
        </div>
        <div className="flex flex-col items-end justify-between self-stretch pt-2 pb-1">
            <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-tighter border ${status === 'Winning' ? 'bg-green-600/10 text-green-400 border-green-500/20' :
                status === 'Outbid' ? 'bg-orange-600/10 text-orange-400 border-orange-500/20' :
                    status === 'Purchased' ? 'bg-blue-600/10 text-blue-400 border-blue-500/20' :
                        'bg-slate-800 text-slate-400 border-white/10'
                }`}>
                {status}
            </span>
            <Link to={`/vehicle/${vehicle.id}`} className="p-3 rounded-xl bg-slate-900 border border-white/5 text-slate-500 hover:text-white transition-all">
                <Eye size={18} />
            </Link>
        </div>
    </div>
);

const EmptyState = ({ message }) => (
    <div className="glass-card rounded-2xl p-10 border-white/5 flex flex-col items-center justify-center text-center">
        <div className="w-12 h-12 rounded-xl bg-slate-800/50 flex items-center justify-center text-slate-600 mb-4">
            <Package size={24} />
        </div>
        <p className="text-slate-500 text-sm font-medium">{message}</p>
    </div>
);


const StatusBadge = ({ status }) => {
    const styles = {
        Live: 'bg-green-600/10 text-green-400 border-green-600/20',
        Sold: 'bg-blue-600/10 text-blue-400 border-blue-600/20',
        Unsold: 'bg-red-600/10 text-red-500 border-red-600/20',
        Success: 'bg-green-600/10 text-green-400',
        Pending: 'bg-yellow-600/10 text-yellow-500',
        Failed: 'bg-red-600/10 text-red-500',
        Active: 'bg-blue-600/10 text-blue-400',
        Refunded: 'bg-slate-800 text-slate-400',
        Forfeited: 'bg-red-900/20 text-red-500',
        Winning: 'bg-green-600/10 text-green-400',
        Outbid: 'bg-orange-600/10 text-orange-400'
    };
    return (
        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter border ${styles[status] || 'bg-slate-700/30 text-slate-400 border-white/5'}`}>
            {status}
        </span>
    );
};

export default BuyerDashboard;
