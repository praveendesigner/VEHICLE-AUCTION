import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import VehicleCard from '../components/VehicleCard';
import { ArrowRight, Sparkles, ShieldCheck, Zap, LayoutGrid, Bus, Tractor, Bike, Car, CarFront, CarTaxiFront } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
    const { allVehicles } = useUser();
    const [activeCategory, setActiveCategory] = useState('All Vehicles');

    const categories = [
        { name: 'All Vehicles', icon: LayoutGrid },
        { name: 'Bus', icon: Bus },
        { name: 'Heavy Machinery', icon: Tractor },
        { name: 'Motor Bikes', icon: Bike },
        { name: 'SUV', icon: CarFront },
        { name: 'Sedan', icon: Car },
        { name: 'Normal Cars', icon: CarTaxiFront }
    ];

    const getVehiclesToShow = () => {
        const limit = 4;
        if (activeCategory === 'All Vehicles') {
            return allVehicles.slice(0, limit);
        }
        return allVehicles.filter(v => v.category === activeCategory).slice(0, limit);
    };

    const vehiclesToShow = getVehiclesToShow();

    return (
        <div className="space-y-16 pb-20">
            {/* Categories Navigation */}
            <section className="px-6 pt-12 max-w-7xl mx-auto">
                <div className="text-center mb-16">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-6">
                        Explore <span className="gradient-text">Categories</span>
                    </h1>
                    <p className="text-slate-400 text-lg max-w-2xl mx-auto">
                        Browse our wide range of premium vehicles across different categories.
                        Find the perfect auction for your needs.
                    </p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-20">
                    {categories.map(cat => (
                        <button
                            key={cat.name}
                            onClick={() => setActiveCategory(cat.name)}
                            className={`group flex flex-col items-center justify-center p-6 rounded-3xl transition-all duration-300 active:scale-95 border ${activeCategory === cat.name
                                ? 'bg-blue-600/20 border-blue-500 shadow-lg shadow-blue-500/10'
                                : 'glass-card border-white/5 hover:border-blue-500/30'
                                }`}
                        >
                            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-3 transition-all ${activeCategory === cat.name
                                ? 'bg-blue-600 shadow-lg shadow-blue-600/30'
                                : 'bg-slate-800 group-hover:bg-blue-600/50'
                                }`}>
                                <cat.icon className={`${activeCategory === cat.name ? 'text-white' : 'text-slate-400 group-hover:text-white'} transition-colors`} size={28} />
                            </div>
                            <span className={`text-xs font-bold transition-colors ${activeCategory === cat.name ? 'text-white' : 'text-slate-300 group-hover:text-white'}`}>{cat.name}</span>
                        </button>
                    ))}
                </div>

                {/* Content Section */}
                <div className="animate-fade-in">
                    <div className="flex flex-col md:flex-row justify-between items-end gap-4 mb-10 pb-6 border-b border-white/5">
                        <div>
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-600/10 border border-blue-600/20 text-blue-400 text-xs font-bold uppercase tracking-widest mb-3">
                                {activeCategory === 'All Vehicles' ? 'Curated Selection' : 'Premium Collection'}
                            </div>
                            <h2 className="text-4xl font-black text-white">{activeCategory}</h2>
                        </div>
                        <Link to="/vehicles" className="group flex items-center gap-2 text-blue-400 hover:text-blue-300 font-bold transition-all">
                            Browse all {activeCategory === 'All Vehicles' ? 'Auctions' : activeCategory} <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                        </Link>
                    </div>

                    {vehiclesToShow.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            {vehiclesToShow.map(vehicle => (
                                <VehicleCard key={vehicle.id} vehicle={vehicle} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-20 glass-card rounded-3xl border-white/5">
                            <p className="text-slate-500 text-xl font-medium">No vehicles found in this category yet.</p>
                        </div>
                    )}
                </div>
            </section>





            {/* Features Section */}
            <section className="px-6 py-20 bg-slate-900/40 border-y border-white/5">
                <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
                    <div className="space-y-4">
                        <div className="w-14 h-14 bg-blue-600/20 text-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                            <ShieldCheck size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-white">Verified Vehicles</h3>
                        <p className="text-slate-500 text-sm leading-relaxed">
                            Every vehicle on our platform undergoes a rigorous inspection process to ensure transparency.
                        </p>
                    </div>
                    <div className="space-y-4">
                        <div className="w-14 h-14 bg-indigo-600/20 text-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                            <Zap size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-white">Instant Bidding</h3>
                        <p className="text-slate-500 text-sm leading-relaxed">
                            Place bids in real-time with our high-speed auction engine. No lag, no compromise.
                        </p>
                    </div>
                    <div className="space-y-4">
                        <div className="w-14 h-14 bg-purple-600/20 text-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                            <ShieldCheck size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-white">Secure Payments</h3>
                        <p className="text-slate-500 text-sm leading-relaxed">
                            Escrow-based payment system ensures both buyers and sellers are protected throughout the deal.
                        </p>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;
