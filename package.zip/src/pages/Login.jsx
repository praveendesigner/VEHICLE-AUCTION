import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { users } from '../data/mockData';
import { Car, ArrowRight, ShieldCheck, UserCircle2, Mail, Lock, AlertCircle } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';

const Login = () => {
    const { login, switchRole } = useUser();
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        setError('');

        const result = login(email, password);
        if (result.success) {
            navigate(`/${result.user.role}-dashboard`);
        } else {
            setError(result.message);
        }
    };

    const handleRoleQuickSwitch = (user) => {
        setEmail(user.email);
        setPassword(user.password);
    };

    return (
        <div className="min-h-[90vh] flex flex-col items-center justify-center px-6 py-12">
            <div className="w-full max-w-md space-y-8">
                <div className="text-center">
                    <div className="bg-blue-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-blue-600/30">
                        <Car className="text-white w-10 h-10" />
                    </div>
                    <h1 className="text-4xl font-black text-white mb-2 tracking-tight">DriveBid</h1>
                    <p className="text-slate-500 font-medium">Enter your credentials to access your dashboard.</p>
                </div>

                <div className="glass-card rounded-3xl p-8 border-white/5 space-y-6">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Email Address</label>
                            <div className="relative">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                <input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                                    placeholder="name@example.com"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Password</label>
                            <div className="relative">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                                    placeholder="••••••••"
                                    required
                                />
                            </div>
                        </div>

                        {error && (
                            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl flex items-center gap-2 text-sm font-medium">
                                <AlertCircle size={18} />
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            className="w-full btn-primary py-4 rounded-xl flex items-center justify-center gap-2"
                        >
                            Sign In <ArrowRight size={18} />
                        </button>
                    </form>

                    <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-white/5"></div>
                        </div>
                        <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest">
                            <span className="bg-[#0f172a] px-4 text-slate-600">Quick Autofill Roles</span>
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                        {users.map((user) => (
                            <button
                                key={user.id}
                                onClick={() => handleRoleQuickSwitch(user)}
                                className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-slate-800/40 border border-white/5 hover:border-blue-500/50 hover:bg-slate-800 transition-all group"
                                title={`Autofill as ${user.name}`}
                            >
                                <div className="w-10 h-10 rounded-full border border-slate-700 overflow-hidden">
                                    <img src={user.avatar} alt="" className="w-full h-full object-cover" />
                                </div>
                                <span className="text-[10px] text-slate-500 font-black uppercase tracking-tighter group-hover:text-blue-400">
                                    {user.role}
                                </span>
                            </button>
                        ))}
                    </div>

                    {/* Credentials Helper Section */}
                    <div className="pt-4 border-t border-white/5">
                        <h3 className="text-[10px] font-black uppercase text-slate-600 tracking-widest mb-4 flex items-center gap-2">
                            <ShieldCheck size={12} /> Test Credentials
                        </h3>
                        <div className="space-y-3">
                            {users.map(u => (
                                <div key={u.id} className="bg-white/5 p-3 rounded-xl border border-white/5 flex justify-between items-center group hover:bg-white/10 transition-all">
                                    <div>
                                        <p className="text-[10px] text-blue-400 font-black uppercase tracking-wider">{u.role}</p>
                                        <p className="text-xs text-white font-medium">{u.email}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter">Password</p>
                                        <p className="text-xs text-slate-400 font-mono font-bold">{u.password}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="text-center">
                        <p className="text-sm text-slate-500">
                            Don't have an account? <Link to="/register" className="text-blue-500 font-bold hover:underline">Sign Up</Link>
                        </p>
                    </div>
                </div>

                <div className="flex items-center justify-center gap-6 text-slate-600">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-tighter">
                        <ShieldCheck size={14} /> Encrypted
                    </div>
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-tighter">
                        <UserCircle2 size={14} /> Verified
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
