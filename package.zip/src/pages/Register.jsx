import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { Car, ArrowRight, ShieldCheck, UserCircle2, Mail, Lock, User, Briefcase, Gavel, Phone } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';

const Register = () => {
    const { register } = useUser();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        mobile: '',
        password: '',
        role: 'buyer' // Default role
    });
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        setError('');

        const result = register(formData);
        if (result.success) {
            navigate(`/${result.user.role}-dashboard`);
        } else {
            setError(result.message);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
        <div className="min-h-[90vh] flex flex-col items-center justify-center px-6 py-12">
            <div className="w-full max-w-md space-y-8">
                <div className="text-center">
                    <div className="bg-blue-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-blue-600/30">
                        <Car className="text-white w-10 h-10" />
                    </div>
                    <h1 className="text-4xl font-black text-white mb-2 tracking-tight">Create Account</h1>
                    <p className="text-slate-500 font-medium">Join DriveBid to start buying and selling.</p>
                </div>

                <div className="glass-card rounded-3xl p-8 border-white/5 space-y-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Full Name</label>
                            <div className="relative">
                                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                <input
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
                                    placeholder="John Doe"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Email Address</label>
                            <div className="relative">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                <input
                                    type="email"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleChange}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
                                    placeholder="name@example.com"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Mobile Number</label>
                            <div className="relative">
                                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                <input
                                    type="text"
                                    name="mobile"
                                    value={formData.mobile}
                                    onChange={handleChange}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
                                    placeholder="+1 234 567 890"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Password</label>
                            <div className="relative">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                <input
                                    type="password"
                                    name="password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
                                    placeholder="••••••••"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Initial Role</label>
                            <div className="grid grid-cols-2 gap-4">
                                <button
                                    type="button"
                                    onClick={() => setFormData({ ...formData, role: 'buyer' })}
                                    className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${formData.role === 'buyer'
                                        ? 'bg-blue-600/10 border-blue-500 text-white'
                                        : 'bg-slate-900 border-white/5 text-slate-500 hover:text-slate-300'
                                        }`}
                                >
                                    <Gavel size={20} />
                                    <span className="text-xs font-bold uppercase tracking-widest">Buyer</span>
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setFormData({ ...formData, role: 'seller' })}
                                    className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${formData.role === 'seller'
                                        ? 'bg-blue-600/10 border-blue-500 text-white'
                                        : 'bg-slate-900 border-white/5 text-slate-500 hover:text-slate-300'
                                        }`}
                                >
                                    <Briefcase size={20} />
                                    <span className="text-xs font-bold uppercase tracking-widest">Seller</span>
                                </button>
                            </div>
                            <p className="text-[10px] text-slate-600 font-medium text-center italic mt-2">
                                * Both roles can buy and sell vehicles. This just sets your default dashboard.
                            </p>
                        </div>

                        {error && (
                            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl flex items-center gap-2 text-sm font-medium">
                                <ShieldCheck size={18} />
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            className="w-full btn-primary py-4 rounded-xl flex items-center justify-center gap-2 mt-4"
                        >
                            Sign Up <ArrowRight size={18} />
                        </button>
                    </form>

                    <div className="text-center">
                        <p className="text-sm text-slate-500">
                            Already have an account? <Link to="/login" className="text-blue-500 font-bold hover:underline">Sign In</Link>
                        </p>
                    </div>
                </div>

                <div className="flex items-center justify-center gap-6 text-slate-600">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-tighter">
                        <ShieldCheck size={14} /> Encrypted
                    </div>
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-tighter">
                        <UserCircle2 size={14} /> Verified
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;
