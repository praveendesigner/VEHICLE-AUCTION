import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { Link, useNavigate } from 'react-router-dom';
import {
    User, Car, CreditCard, ShieldCheck, FileText, Settings,
    ChevronRight, LogOut, Package, Gavel, Timer, CheckCircle2,
    Clock, Bell, Camera, UserCircle, Mail, Phone, Hash, Upload, Download, Trash2, Eye,
    Plus, LayoutGrid, Edit3, X, AlertCircle, Save, Send, History, CloudUpload, Activity, ShieldAlert
} from 'lucide-react';
import CountdownTimer from '../components/CountdownTimer';

const SellerDashboard = () => {
    const navigate = useNavigate();
    const {
        currentUser, allVehicles, pendingVehicles, drafts, allBids,
        vehiclePayments, userDocuments,
        updateProfile, uploadDocument, submitListing, saveDraft, logout, updateVehicle
    } = useUser();

    const [activeSection, setActiveSection] = useState('Overview');
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [isEditingProfile, setIsEditingProfile] = useState(false);
    const [profileData, setProfileData] = useState({
        name: currentUser?.name || '',
        email: currentUser?.email || '',
        mobile: currentUser?.mobile || ''
    });

    const sellerVehicles = allVehicles.filter(v => v.sellerId === currentUser?.id);
    const myPending = pendingVehicles.filter(pv => pv.sellerId === currentUser?.id);
    const myDrafts = drafts.filter(d => d.sellerId === currentUser?.id);
    const mySoldVehicles = sellerVehicles.filter(v => v.status === 'Sold');
    const myActiveAuctions = sellerVehicles.filter(v => v.status === 'Live');

    const [vehicleTab, setVehicleTab] = useState('Active');
    const vehicleTabs = [
        { id: 'Active', label: 'Active Auctions', count: myActiveAuctions.length, icon: Activity, status: 'Live' },
        { id: 'Pending', label: 'Awaiting Approval', count: myPending.length, icon: ShieldAlert, status: 'Pending' },
        { id: 'Sold', label: 'Sold Vehicles', count: mySoldVehicles.length, icon: CheckCircle2, status: 'Sold' },
    ];

    // Payments received (mock logic: payments for my vehicles)
    const myPayments = vehiclePayments.filter(p => {
        const v = allVehicles.find(v => v.id === p.vehicleId);
        return v && v.sellerId === currentUser?.id;
    });

    const menuItems = [
        { id: 'Overview', icon: LayoutGrid, label: 'Overview' },
        { id: 'Profile', icon: UserCircle, label: 'My Profile' },
        { id: 'Vehicles', icon: Car, label: 'My Vehicles' },
        { id: 'Payments', icon: CreditCard, label: 'Income & Ledger' },
        { id: 'Documents', icon: FileText, label: 'My Documents' },
    ];

    const [formData, setFormData] = useState({
        name: '',
        brand: 'Mercedes',
        model: 'Model S',
        year: '2024',
        color: 'Black',
        mileage: '',
        targetPrice: '',
        fuel: 'Petrol',
        transmission: 'Automatic',
        description: '',
        images: []
    });

    const handlePhotoUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData({ ...formData, images: [...formData.images, reader.result] });
            };
            reader.readAsDataURL(file);
        }
    };

    const removePhoto = (index) => {
        setFormData({ ...formData, images: formData.images.filter((_, i) => i !== index) });
    };

    const handleAction = (type) => {
        if (!formData.name || !formData.targetPrice) {
            alert('Please fill at least Vehicle Name and Target Price');
            return;
        }

        if (editingId) {
            updateVehicle(editingId, formData);
        } else if (type === 'Submit') {
            submitListing(formData);
        } else {
            saveDraft(formData);
        }

        setShowForm(false);
        setEditingId(null);
        setFormData({ name: '', brand: 'Mercedes', model: 'Model S', year: '2024', color: 'Black', mileage: '', targetPrice: '', fuel: 'Petrol', transmission: 'Automatic', description: '', images: [] });
    };

    const handleEdit = (vehicle) => {
        setEditingId(vehicle.id);
        const [brand, year, fuel] = (vehicle.brand || '').split(' • '); // Fallback if brand string is complex, usually simplistic mock data

        // Better parsing based on actual mock structure
        setFormData({
            name: vehicle.name || '',
            brand: vehicle.brand || 'Mercedes',
            model: vehicle.model || '',
            year: vehicle.year?.toString() || '2024',
            color: vehicle.color || 'Black',
            mileage: vehicle.kmDriven || '',
            targetPrice: vehicle.basePrice || vehicle.currentBid || '',
            fuel: vehicle.fuel || 'Petrol',
            transmission: vehicle.transmission || 'Automatic',
            description: vehicle.description || '',
            images: vehicle.images || []
        });
        setShowForm(true);
    };


    return (
        <div className="min-h-screen bg-[#0f172a] flex flex-col lg:flex-row">
            {/* Sidebar Navigation */}
            <aside className="w-full lg:w-72 bg-slate-900 border-r border-white/5 flex flex-col p-6 lg:pt-28 space-y-10 lg:fixed lg:top-0 lg:left-0 lg:h-full z-[60]">
                <div className="flex items-center gap-4 px-2">
                    <img src={currentUser?.avatar} className="w-12 h-12 rounded-2xl border border-indigo-500/20" alt="" />
                    <div>
                        <h2 className="text-white font-black text-sm">{currentUser?.name}</h2>
                        <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">{currentUser?.role}</p>
                    </div>
                </div>

                <nav className="flex-1 space-y-2">
                    {menuItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => setActiveSection(item.id)}
                            className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl font-bold transition-all duration-300 ${activeSection === item.id
                                ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/20'
                                : 'text-slate-500 hover:text-white hover:bg-white/5'
                                }`}
                        >
                            <item.icon size={20} />
                            <span className="text-sm">{item.label}</span>
                            {activeSection === item.id && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>}
                        </button>
                    ))}
                    <button
                        onClick={() => {
                            setEditingId(null);
                            setFormData({ name: '', brand: 'Mercedes', model: 'Model S', year: '2024', color: 'Black', mileage: '', targetPrice: '', fuel: 'Petrol', transmission: 'Automatic', description: '', images: [] });
                            setShowForm(true);
                        }}
                        className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl font-black bg-white text-slate-950 hover:bg-slate-200 transition-all mt-6 shadow-xl"
                    >
                        <Plus size={20} />
                        <span className="text-sm">List New Vehicle</span>
                    </button>
                </nav>

                <button
                    onClick={() => { logout(); navigate('/'); }}
                    className="flex items-center gap-4 px-4 py-4 rounded-2xl font-bold text-red-500 hover:bg-red-500/10 transition-all border border-transparent hover:border-red-500/20"
                >
                    <LogOut size={20} />
                    <span className="text-sm">Log Out</span>
                </button>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 lg:ml-72 p-6 md:p-12">
                <header className="mb-12">
                    <div className="flex items-center gap-3 text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">
                        <span>Seller Workspace</span>
                        <ChevronRight size={14} />
                        <span className="text-indigo-500">{activeSection}</span>
                    </div>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                        <h1 className="text-4xl md:text-5xl font-black text-white">{activeSection}</h1>
                        <div className="flex gap-4">
                            <div className="glass-card py-2 px-6 rounded-2xl border-white/5">
                                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-1">Total Sales</span>
                                <span className="text-xl font-black text-indigo-400">${myPayments.reduce((acc, p) => acc + p.amount, 0).toLocaleString()}</span>
                            </div>
                        </div>
                    </div>
                </header>

                <div className="animate-fade-in">
                    {activeSection === 'Overview' && (
                        <div className="space-y-10">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                <SummaryCard label="My Sold Fleet" value={mySoldVehicles.length} icon={ShieldCheck} color="text-green-400" bg="bg-green-400/10" />
                                <SummaryCard label="Active Auctions" value={myActiveAuctions.length} icon={Activity} color="text-indigo-400" bg="bg-indigo-400/10" />
                                <SummaryCard label="Pending Approval" value={myPending.length} icon={Clock} color="text-yellow-400" bg="bg-yellow-400/10" />
                                <SummaryCard label="My Drafts" value={myDrafts.length} icon={Edit3} color="text-slate-400" bg="bg-slate-400/10" />
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                <div className="glass-card rounded-3xl p-8 border-white/5">
                                    <h3 className="text-xl font-bold text-white mb-6">Recent Sales Income</h3>
                                    <div className="space-y-6">
                                        {myPayments.slice(0, 4).map(p => (
                                            <div key={p.id} className="flex justify-between items-center py-4 border-b border-white/5 last:border-0">
                                                <div className="flex gap-4 items-center">
                                                    <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-green-500">
                                                        <CheckCircle2 size={24} />
                                                    </div>
                                                    <div>
                                                        <p className="text-white text-sm font-bold">{allVehicles.find(v => v.id === p.vehicleId)?.name}</p>
                                                        <p className="text-slate-500 text-[10px] font-medium uppercase">{p.date}</p>
                                                    </div>
                                                </div>
                                                <p className="text-xl font-black text-white">${p.amount.toLocaleString()}</p>
                                            </div>
                                        ))}
                                        {myPayments.length === 0 && <p className="text-center text-slate-500 py-10">No income records available yet.</p>}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeSection === 'Profile' && (
                        <div className="max-w-3xl">
                            <div className="glass-card rounded-3xl p-10 border-white/5 space-y-10">
                                <div className="flex flex-col md:flex-row items-center gap-10 border-b border-white/5 pb-10">
                                    <div className="relative group">
                                        <img src={currentUser?.avatar} className="w-32 h-32 rounded-3xl border-2 border-indigo-500/20" alt="" />
                                        <button className="absolute -bottom-2 -right-2 bg-indigo-600 p-3 rounded-2xl text-white shadow-xl hover:scale-110 transition-transform">
                                            <Camera size={20} />
                                        </button>
                                    </div>
                                    <div className="flex-1 text-center md:text-left space-y-2">
                                        <h2 className="text-3xl font-black text-white">{currentUser?.name}</h2>
                                        <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest tracking-widest">Platform Seller Verified</p>
                                    </div>
                                    <button
                                        onClick={() => setIsEditingProfile(!isEditingProfile)}
                                        className="px-8 py-3 rounded-xl bg-indigo-600 text-white font-bold"
                                    >
                                        {isEditingProfile ? 'Cancel' : 'Edit Profile'}
                                    </button>
                                </div>

                                {isEditingProfile ? (
                                    <form onSubmit={(e) => { e.preventDefault(); updateProfile(currentUser.id, profileData); setIsEditingProfile(false); }} className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                        <ProfileInput label="Full Name" value={profileData.name} onChange={(e) => setProfileData({ ...profileData, name: e.target.value })} icon={User} />
                                        <ProfileInput label="Email Address" value={profileData.email} onChange={(e) => setProfileData({ ...profileData, email: e.target.value })} icon={Mail} type="email" />
                                        <ProfileInput label="Mobile Number" value={profileData.mobile} onChange={(e) => setProfileData({ ...profileData, mobile: e.target.value })} icon={Phone} />
                                        <div className="md:col-span-2 pt-4">
                                            <button type="submit" className="w-full bg-white text-slate-950 py-4 rounded-2xl font-black uppercase tracking-widest">Update Merchant Profile</button>
                                        </div>
                                    </form>
                                ) : (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                        <ProfileData label="Full Name" value={currentUser?.name} icon={User} />
                                        <ProfileData label="Merchant ID" value={currentUser?.id} icon={Hash} />
                                        <ProfileData label="Business Email" value={currentUser?.email} icon={Mail} />
                                        <ProfileData label="Contact Number" value={currentUser?.mobile || '+1 800-SELL-CAR'} icon={Phone} />
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {activeSection === 'Vehicles' && (
                        <div className="space-y-8">
                            {/* Sub-tabs for Vehicles */}
                            <div className="flex border-b border-white/5 pb-2 gap-8 overflow-x-auto no-scrollbar">
                                {vehicleTabs.map(tab => (
                                    <button
                                        key={tab.id}
                                        onClick={() => setVehicleTab(tab.id)}
                                        className={`relative pb-2 flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] transition-all ${vehicleTab === tab.id ? 'text-indigo-500' : 'text-slate-500 hover:text-white'}`}
                                    >
                                        <tab.icon size={14} />
                                        {tab.label}
                                        <span className={`ml-1 px-2 py-0.5 rounded-full text-[8px] ${vehicleTab === tab.id ? 'bg-indigo-500/10 text-indigo-400' : 'bg-slate-800 text-slate-500'}`}>
                                            {tab.count}
                                        </span>
                                        {vehicleTab === tab.id && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500 rounded-full shadow-[0_0_10px_rgba(99,102,241,0.5)]"></div>}
                                    </button>
                                ))}
                            </div>

                            <div className="grid grid-cols-1 gap-6 animate-fade-in">
                                {vehicleTab === 'Active' && (
                                    <>
                                        {myActiveAuctions.map(v => <SellerVehicleCard key={v.id} vehicle={v} status="Live" onEdit={() => handleEdit(v)} />)}
                                        {myActiveAuctions.length === 0 && <EmptyState message="You have no active auctions." />}
                                    </>
                                )}
                                {vehicleTab === 'Pending' && (
                                    <>
                                        {myPending.map(v => <SellerVehicleCard key={v.id} vehicle={v} status="Pending" onEdit={() => handleEdit(v)} />)}
                                        {myPending.length === 0 && <EmptyState message="No vehicles awaiting approval." />}
                                    </>
                                )}
                                {vehicleTab === 'Sold' && (
                                    <>
                                        {mySoldVehicles.map(v => <SellerVehicleCard key={v.id} vehicle={v} status="Sold" onEdit={() => handleEdit(v)} />)}
                                        {mySoldVehicles.length === 0 && <EmptyState message="You haven't sold any vehicles yet." />}
                                    </>
                                )}
                            </div>
                        </div>
                    )}

                    {activeSection === 'Payments' && (
                        <div className="glass-card rounded-3xl overflow-hidden border-white/5">
                            <table className="w-full text-left">
                                <thead className="bg-slate-900/50 border-b border-white/5">
                                    <tr>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Transaction</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Payout Amount</th>
                                        <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Date</th>
                                        <th className="px-6 py-4 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {myPayments.map(p => (
                                        <tr key={p.id} className="hover:bg-white/5 transition-colors">
                                            <td className="px-6 py-4">
                                                <p className="text-white font-bold text-sm">{allVehicles.find(v => v.id === p.vehicleId)?.name}</p>
                                                <p className="text-slate-500 text-[10px]">Buyer: {p.userId}</p>
                                            </td>
                                            <td className="px-6 py-4 text-white font-black">${p.amount.toLocaleString()}</td>
                                            <td className="px-6 py-4 text-slate-500 text-xs font-medium">{p.date}</td>
                                            <td className="px-6 py-4 text-right">
                                                <StatusBadge status={p.status === 'Completed' ? 'Success' : p.status} />
                                            </td>
                                        </tr>
                                    ))}
                                    {myPayments.length === 0 && (
                                        <tr><td colSpan="4" className="px-6 py-20 text-center text-slate-600">No payment history available.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {activeSection === 'Documents' && (
                        <div className="space-y-8">
                            <div className="glass-card rounded-3xl p-10 border-white/5 flex flex-col items-center justify-center text-center space-y-4">
                                <CloudUpload size={40} className="text-indigo-400" />
                                <div>
                                    <h3 className="text-xl font-bold text-white">Upload Merchant Documents</h3>
                                    <p className="text-slate-500 text-sm max-w-sm">Securely store your permit, business license, and KYC data.</p>
                                </div>
                                <input type="file" id="seller-doc-upload" className="hidden" onChange={(e) => {
                                    const file = e.target.files[0];
                                    if (file) {
                                        const reader = new FileReader();
                                        reader.onloadend = () => uploadDocument({ name: file.name, type: file.type, size: (file.size / 1024).toFixed(2) + 'KB', data: reader.result });
                                        reader.readAsDataURL(file);
                                    }
                                }} />
                                <label htmlFor="seller-doc-upload" className="px-10 py-4 bg-indigo-600 rounded-2xl text-white font-black uppercase tracking-widest cursor-pointer shadow-xl shadow-indigo-600/20">
                                    Upload Document
                                </label>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {userDocuments.filter(doc => doc.userId === currentUser.id).map(doc => (
                                    <div key={doc.id} className="glass-card rounded-2xl p-6 border-white/5 hover:border-indigo-500/20 transition-all">
                                        <div className="flex gap-4 mb-4">
                                            <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-indigo-400">
                                                <History size={24} />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h4 className="text-white font-bold text-sm truncate">{doc.name}</h4>
                                                <p className="text-[10px] text-slate-500 font-bold uppercase">{doc.size} • {new Date(doc.timestamp).toLocaleDateString()}</p>
                                            </div>
                                        </div>
                                        <button className="w-full py-2 rounded-xl border border-white/5 text-slate-500 hover:text-white transition-all text-[10px] font-black uppercase">Download</button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {/* Listing Modal */}
                {showForm && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-xl">
                        <div className="glass-card w-full max-w-4xl rounded-[2.5rem] p-10 border-indigo-500/20 shadow-2xl relative max-h-[90vh] overflow-y-auto">
                            <button onClick={() => setShowForm(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white transition-colors p-2 bg-white/5 rounded-full"><X size={24} /></button>

                            <div className="mb-10">
                                <h2 className="text-4xl font-black text-white mb-2 tracking-tight">Direct Vehicle Upload</h2>
                                <p className="text-slate-500 font-medium">Complete the form below to initiate an auction listing for your asset.</p>
                            </div>

                            <form className="space-y-12 pb-10">
                                <section className="space-y-8">
                                    <h3 className="text-xs font-black text-indigo-400 uppercase tracking-[0.3em] border-b border-white/5 pb-4">A. Core Information</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                        <SelectField label="Vehicle Make" options={['Mercedes', 'Tesla', 'BMW', 'Audi', 'Porsche', 'Toyota']} value={formData.brand} onChange={val => setFormData({ ...formData, brand: val })} />
                                        <SelectField label="Model Version" options={['Model S', 'M3 Competition', '911 GT3', 'AMG G63', 'Land Cruiser']} value={formData.model} onChange={val => setFormData({ ...formData, model: val })} />
                                        <SelectField label="Year (YOM)" options={['2024', '2023', '2022', '2021', '2020', '2019']} value={formData.year} onChange={val => setFormData({ ...formData, year: val })} />
                                        <SelectField label="Exterior Color" options={['Black', 'White', 'Silver', 'Red', 'Blue', 'Custom']} value={formData.color} onChange={val => setFormData({ ...formData, color: val })} />
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        <div className="md:col-span-2">
                                            <InputField label="Registered Vehicle Name" placeholder="e.g. 2023 Tesla Model S Plaid - Performance Spec" value={formData.name} onChange={val => setFormData({ ...formData, name: val })} />
                                        </div>
                                        <InputField label="Mileage (KM)" placeholder="e.g. 15400" type="number" value={formData.mileage} onChange={val => setFormData({ ...formData, mileage: val })} />
                                    </div>
                                </section>

                                <section className="space-y-8">
                                    <h3 className="text-xs font-black text-indigo-400 uppercase tracking-[0.3em] border-b border-white/5 pb-4">B. Pricing & Logistics</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                        <div className="md:col-span-2 space-y-2">
                                            <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1">Target Sale Price ($)</label>
                                            <div className="relative">
                                                <div className="absolute left-6 top-1/2 -translate-y-1/2 text-indigo-400 font-black text-2xl">$</div>
                                                <input
                                                    type="number"
                                                    required
                                                    value={formData.targetPrice}
                                                    onChange={(e) => setFormData({ ...formData, targetPrice: e.target.value })}
                                                    className="w-full bg-slate-900/50 border border-white/10 rounded-3xl pl-16 pr-8 py-6 text-3xl font-black text-white focus:ring-4 focus:ring-indigo-600/20 focus:border-indigo-600 outline-none transition-all"
                                                />
                                            </div>
                                        </div>
                                        <SelectField label="Fuel Technology" options={['Petrol', 'Diesel', 'Electric', 'Hybrid']} value={formData.fuel} onChange={val => setFormData({ ...formData, fuel: val })} />
                                    </div>
                                </section>

                                <section className="space-y-8">
                                    <h3 className="text-xs font-black text-indigo-400 uppercase tracking-[0.3em] border-b border-white/5 pb-4">C. Visual Assets</h3>
                                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                                        {formData.images.map((img, i) => (
                                            <div key={i} className="relative aspect-square rounded-3xl overflow-hidden group">
                                                <img src={img} className="w-full h-full object-cover" alt="" />
                                                <button type="button" onClick={() => removePhoto(i)} className="absolute top-2 right-2 bg-red-600 p-2 rounded-xl text-white opacity-0 group-hover:opacity-100 transition-opacity"><X size={14} /></button>
                                            </div>
                                        ))}
                                        <input type="file" id="seller-photo" className="hidden" accept="image/*" onChange={handlePhotoUpload} />
                                        <label htmlFor="seller-photo" className="aspect-square rounded-3xl border-2 border-dashed border-white/10 hover:border-indigo-600/50 hover:bg-indigo-600/5 flex flex-col items-center justify-center text-slate-500 hover:text-indigo-400 transition-all cursor-pointer gap-2">
                                            <Plus size={32} />
                                            <span className="text-[10px] font-black uppercase">Add Photo</span>
                                        </label>
                                    </div>
                                </section>

                                <div className="flex flex-col md:flex-row justify-end gap-6 pt-10 border-t border-white/5">
                                    <button type="button" onClick={() => handleAction('Draft')} className="flex items-center justify-center gap-3 px-10 py-5 rounded-2xl bg-white/5 text-white font-black uppercase tracking-widest hover:bg-white/10 transition-all">
                                        <Save size={20} /> Save as Draft
                                    </button>
                                    <button type="button" onClick={() => handleAction('Submit')} className="flex items-center justify-center gap-3 px-16 py-5 rounded-2xl bg-indigo-600 text-white font-black uppercase tracking-widest hover:bg-indigo-500 shadow-2xl shadow-indigo-600/30 transition-all">
                                        <Send size={20} /> Submit for Approval
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};

// Helper components
const SummaryCard = ({ label, value, icon: Icon, color, bg }) => (
    <div className="glass-card rounded-3xl p-8 border-white/5 relative group overflow-hidden transition-all duration-500 hover:translate-y-[-4px]">
        <div className={`w-14 h-14 ${bg} ${color} rounded-2xl flex items-center justify-center mb-6`}>
            <Icon size={28} />
        </div>
        <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mb-2">{label}</p>
        <p className="text-4xl font-black text-white">{value}</p>
        <div className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full bg-white/[0.02] group-hover:scale-150 transition-transform duration-700"></div>
    </div>
);

const ProfileInput = ({ label, value, onChange, icon: Icon, type = 'text' }) => (
    <div className="space-y-2">
        <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1">{label}</label>
        <div className="relative">
            <Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input
                type={type}
                required
                value={value}
                onChange={onChange}
                className="w-full bg-slate-900/50 border border-white/5 rounded-2xl pl-12 pr-4 py-5 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all"
            />
        </div>
    </div>
);

const ProfileData = ({ label, value, icon: Icon }) => (
    <div className="flex gap-6 items-center">
        <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-indigo-500">
            <Icon size={24} />
        </div>
        <div>
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">{label}</p>
            <p className="text-white font-bold">{value || '--'}</p>
        </div>
    </div>
);

const SelectField = ({ label, options, value, onChange }) => (
    <div className="space-y-2">
        <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1">{label}</label>
        <select
            value={value}
            onChange={e => onChange(e.target.value)}
            className="w-full bg-slate-900 border border-white/10 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-indigo-500/30 outline-none appearance-none cursor-pointer"
        >
            {options.map(opt => <option key={opt}>{opt}</option>)}
        </select>
    </div>
);

const InputField = ({ label, placeholder, type = 'text', value, onChange }) => (
    <div className="space-y-2">
        <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1">{label}</label>
        <input
            type={type}
            placeholder={placeholder}
            value={value}
            onChange={e => onChange(e.target.value)}
            className="w-full bg-slate-900 border border-white/10 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-indigo-500/30 outline-none transition-all"
        />
    </div>
);

const SellerVehicleCard = ({ vehicle, status, onEdit }) => (
    <div className="glass-card rounded-[2rem] p-6 border-white/5 flex flex-col md:flex-row items-center gap-8 hover:border-indigo-500/20 transition-all group relative">
        <div className="w-full md:w-56 h-40 rounded-3xl overflow-hidden shrink-0">
            <img src={vehicle.images?.[0] || 'https://images.unsplash.com/photo-1503376780353-7e6692767b70'} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="" />
        </div>
        <div className="flex-1 min-w-0 py-2">
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h3 className="text-2xl font-black text-white group-hover:text-indigo-400 transition-colors">{vehicle.name}</h3>
                    <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">{vehicle.brand} • {vehicle.year} • {vehicle.fuel}</p>
                </div>
                <div className="text-right">
                    <p className="text-2xl font-black text-white">${(vehicle.currentBid || vehicle.targetPrice || 0).toLocaleString()}</p>
                    <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">{status === 'Sold' ? 'Sold Price' : 'Highest Bid'}</p>
                </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4 border-y border-white/5 mb-6">
                <MetricItem label="Status" value={<StatusBadge status={status} />} />
                {status === 'Live' && <MetricItem label="Ending In" value={<CountdownTimer endTime={vehicle.endTime} />} />}
                <MetricItem label="ID" value={vehicle.id} />
                <MetricItem label="Views" value="---" />
            </div>

            <div className="flex gap-4">
                <Link to={vehicle.id && vehicle.id.startsWith('pv') ? '#' : `/vehicle/${vehicle.id}`} className="px-6 py-3 rounded-xl bg-indigo-600 text-white font-black text-[10px] uppercase tracking-widest hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/20">View Analytics</Link>
                <button onClick={onEdit} className="px-6 py-3 rounded-xl border border-white/5 text-slate-500 hover:text-white transition-all text-[10px] font-black uppercase">Edit Details</button>
            </div>
        </div>
    </div>
);

const MetricItem = ({ label, value }) => (
    <div>
        <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">{label}</p>
        <div className="text-sm font-bold text-white">{value}</div>
    </div>
);

const EmptyState = ({ message }) => (
    <div className="glass-card rounded-3xl p-12 border-white/5 flex flex-col items-center justify-center text-center space-y-4">
        <div className="bg-slate-800 w-16 h-16 rounded-2xl flex items-center justify-center text-slate-600">
            <Car size={32} />
        </div>
        <p className="text-slate-500 font-medium">{message}</p>
    </div>
);



const StatusBadge = ({ status }) => {
    const styles = {
        Live: 'bg-green-600/10 text-green-400 border-green-600/20',
        Sold: 'bg-blue-600/10 text-blue-400 border-blue-600/20',
        Ended: 'bg-slate-800 text-slate-500 border-white/5',
        Pending: 'bg-yellow-600/10 text-yellow-500 border-yellow-600/20',
        Completed: 'bg-green-600/10 text-green-400',
        Awaiting: 'bg-indigo-600/10 text-indigo-400',
        Draft: 'bg-slate-700/30 text-slate-400 border-white/5'
    };
    return (
        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter border ${styles[status] || 'bg-slate-700/30 text-slate-400 border-white/5'}`}>
            {status}
        </span>
    );
};

export default SellerDashboard;
