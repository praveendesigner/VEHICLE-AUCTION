import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { vehicles, bids as mockBids } from '../data/mockData';
import { useUser } from '../context/UserContext';
import BidList from '../components/BidList';
import CountdownTimer from '../components/CountdownTimer';
import {
    ChevronLeft,
    MapPin,
    Gauge,
    Fuel,
    Calendar,
    Info,
    History,
    Gavel,
    CheckCircle2,
    AlertCircle
} from 'lucide-react';

const VehicleDetails = () => {
    const { id } = useParams();
    const { currentUser, allVehicles, allBids, placeBid } = useUser();
    const vehicle = allVehicles.find(v => v.id === id);
    const vehicleBids = allBids.filter(b => b.vehicleId === id);

    const [activeImage, setActiveImage] = useState(0);
    const [bidAmount, setBidAmount] = useState('');
    const [bidStatus, setBidStatus] = useState(null); // success, error

    if (!vehicle) return <div className="text-center py-20 text-white">Vehicle not found</div>;

    const handlePlaceBid = (e) => {
        e.preventDefault();
        const amount = parseFloat(bidAmount);

        if (isNaN(amount) || amount <= vehicle.currentBid) {
            setBidStatus({ type: 'error', message: `Bid must be higher than $${vehicle.currentBid.toLocaleString()}` });
            return;
        }

        // Role check
        if (currentUser?.role === 'admin') {
            setBidStatus({ type: 'error', message: 'Admin accounts cannot place bids' });
            return;
        }

        const result = placeBid(vehicle.id, amount);
        if (result.success) {
            setBidStatus({ type: 'success', message: 'Bid placed successfully!' });
            setBidAmount('');
            setTimeout(() => setBidStatus(null), 3000);
        }
    };

    return (
        <div className="px-6 max-w-7xl mx-auto py-8">
            <Link to="/vehicles" className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition-colors font-medium">
                <ChevronLeft size={20} /> Back to Auctions
            </Link>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Left Column: Images and Details */}
                <div className="lg:col-span-2 space-y-8">
                    {/* Image Gallery */}
                    <div className="space-y-4">
                        <div className="aspect-[16/9] rounded-3xl overflow-hidden glass-card">
                            <img
                                src={vehicle.images[activeImage]}
                                alt={vehicle.name}
                                className="w-full h-full object-cover transition-opacity duration-500"
                            />
                        </div>
                        {vehicle.images.length > 1 && (
                            <div className="flex gap-4 overflow-x-auto pb-2">
                                {vehicle.images.map((img, idx) => (
                                    <button
                                        key={idx}
                                        onClick={() => setActiveImage(idx)}
                                        className={`relative w-24 aspect-[4/3] rounded-xl overflow-hidden border-2 transition-all ${activeImage === idx ? 'border-blue-500 scale-105' : 'border-slate-800 opacity-60'
                                            }`}
                                    >
                                        <img src={img} alt="" className="w-full h-full object-cover" />
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Description & Specs */}
                    <div className="glass-card rounded-3xl p-8 space-y-8">
                        <div>
                            <h1 className="text-3xl font-black text-white mb-4">{vehicle.name}</h1>
                            <p className="text-slate-400 leading-relaxed text-lg">
                                {vehicle.description}
                            </p>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <Calendar className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Year</p>
                                <p className="text-lg font-black text-white">{vehicle.year}</p>
                            </div>
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <Fuel className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Fuel</p>
                                <p className="text-lg font-black text-white">{vehicle.fuel}</p>
                            </div>
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <Gauge className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Mileage</p>
                                <p className="text-lg font-black text-white">{vehicle.kmDriven.toLocaleString()} km</p>
                            </div>
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <Info className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Transmission</p>
                                <p className="text-lg font-black text-white">{vehicle.transmission || 'Automatic'}</p>
                            </div>
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <History className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Owner</p>
                                <p className="text-lg font-black text-white">{vehicle.ownerType || 'First'}</p>
                            </div>
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <Gauge className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Engine</p>
                                <p className="text-lg font-black text-white">{vehicle.engineCC || '3000'} cc</p>
                            </div>
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <MapPin className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Location</p>
                                <p className="text-lg font-black text-white truncate">{vehicle.location || 'Miami, FL'}</p>
                            </div>
                            <div className="bg-slate-800/40 p-4 rounded-2xl border border-white/5">
                                <Info className="text-blue-500 mb-2" size={20} />
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Power</p>
                                <p className="text-lg font-black text-white">{vehicle.power || '450'} hp</p>
                            </div>
                        </div>

                        {vehicle.features && vehicle.features.length > 0 && (
                            <div className="pt-8 border-t border-white/5">
                                <h3 className="text-sm text-slate-500 font-bold uppercase tracking-[0.2em] mb-4">Prominent Features</h3>
                                <div className="flex flex-wrap gap-3">
                                    {vehicle.features.map(feature => (
                                        <div key={feature} className="flex items-center gap-2 bg-blue-500/10 text-blue-400 px-4 py-2 rounded-xl border border-blue-500/20 text-sm font-bold">
                                            <CheckCircle2 size={16} />
                                            {feature}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Column: Bidding and History */}
                <div className="space-y-8">
                    {/* Bid Card */}
                    <div className="glass-card rounded-3xl p-8 border-blue-500/20 shadow-2xl shadow-blue-500/5">
                        <div className="flex justify-between items-center mb-6">
                            <span className="bg-blue-600/20 text-blue-400 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border border-blue-500/20">
                                Live Auction
                            </span>
                            <div className="text-right">
                                <CountdownTimer endTime={vehicle.endTime} />
                            </div>
                        </div>

                        <div className="mb-8">
                            <span className="text-sm text-slate-500 font-bold uppercase tracking-[0.2em] mb-1 block">Current highest bid</span>
                            <h2 className="text-4xl font-black text-white">${vehicle.currentBid.toLocaleString()}</h2>
                        </div>

                        <form onSubmit={handlePlaceBid} className="space-y-4">
                            <div className="relative">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                                <input
                                    type="number"
                                    placeholder="Enter your bid"
                                    className="w-full bg-slate-900 border border-white/10 rounded-2xl py-4 pl-10 pr-4 text-white font-black placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all text-xl"
                                    value={bidAmount}
                                    onChange={(e) => setBidAmount(e.target.value)}
                                />
                            </div>

                            {bidStatus && (
                                <div className={`p-4 rounded-xl flex items-center gap-3 text-sm font-medium ${bidStatus.type === 'success' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                                    }`}>
                                    {bidStatus.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
                                    {bidStatus.message}
                                </div>
                            )}

                            <button
                                type="submit"
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black text-lg py-4 rounded-2xl shadow-xl shadow-blue-600/30 transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100 flex items-center justify-center gap-3"
                                disabled={vehicle.status === 'Ended'}
                            >
                                <Gavel size={24} />
                                {vehicle.status === 'Ended' ? 'Auction Ended' : 'Place Your Bid'}
                            </button>
                        </form>

                        <p className="text-[10px] text-slate-500 mt-6 text-center leading-relaxed font-bold uppercase tracking-widest">
                            By placing a bid, you agree to our <br />
                            <a href="#" className="underline hover:text-slate-300">Terms & Conditions</a>
                        </p>
                    </div>

                    {/* Bid History */}
                    <div className="glass-card rounded-3xl p-6">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-3">
                            <History size={20} className="text-blue-500" />
                            Bid History
                        </h3>
                        <BidList vehicleBids={vehicleBids} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default VehicleDetails;
