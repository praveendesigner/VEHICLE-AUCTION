import React, { useState, useMemo } from 'react';
import { useUser } from '../context/UserContext';
import VehicleCard from '../components/VehicleCard';
import { Search, Filter, SlidersHorizontal, Car, Zap, Shield, Clock } from 'lucide-react';

const Vehicles = () => {
    const { allVehicles } = useUser();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedBrand, setSelectedBrand] = useState('All');
    const [selectedFuel, setSelectedFuel] = useState('All');
    const [sortBy, setSortBy] = useState('Newest');

    const brands = ['All', ...new Set(allVehicles.map(v => v.brand))];
    const fuelTypes = ['All', ...new Set(allVehicles.map(v => v.fuel))];

    const filteredVehicles = useMemo(() => {
        let filtered = allVehicles.filter(v => v.status === 'Live');

        if (searchTerm) {
            filtered = filtered.filter(v =>
                v.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                v.brand.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        if (selectedBrand !== 'All') {
            filtered = filtered.filter(v => v.brand === selectedBrand);
        }

        if (selectedFuel !== 'All') {
            filtered = filtered.filter(v => v.fuel === selectedFuel);
        }

        if (sortBy === 'Price: Low to High') {
            filtered.sort((a, b) => a.currentBid - b.currentBid);
        } else if (sortBy === 'Price: High to Low') {
            filtered.sort((a, b) => b.currentBid - a.currentBid);
        } else if (sortBy === 'Ending Soon') {
            filtered.sort((a, b) => new Date(a.endTime) - new Date(b.endTime));
        }

        return filtered;
    }, [allVehicles, searchTerm, selectedBrand, selectedFuel, sortBy]);

    return (
        <div className="min-h-screen bg-[#0f172a] text-white pb-20">
            {/* Header Section */}
            <div className="relative pt-32 pb-20 px-6 sm:px-12 lg:px-24 bg-gradient-to-b from-blue-600/10 via-[#0f172a] to-[#0f172a]">
                <div className="max-w-7xl mx-auto flex flex-col items-center text-center space-y-6">
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-black uppercase tracking-widest animate-fade-in">
                        <Zap size={14} /> Global Bidding Live
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black tracking-tighter animate-fade-in-up">
                        The Global <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">Inventory</span>
                    </h1>
                    <p className="text-slate-400 text-lg max-w-2xl font-medium animate-fade-in-up delay-100">
                        Explore our curated selection of premium vehicles, from performance icons to electric masterpieces.
                    </p>
                </div>
            </div>

            {/* Filter & Search Bar */}
            <div className="sticky top-0 z-40 bg-[#0f172a]/80 backdrop-blur-xl border-y border-white/5 py-4 px-6 sm:px-12 lg:px-24">
                <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-6 items-center">
                    {/* Search */}
                    <div className="relative flex-1 group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition-colors" size={20} />
                        <input
                            type="text"
                            placeholder="Search by make, model..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-slate-900/50 border border-white/10 rounded-2xl pl-12 pr-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500/50 transition-all font-medium"
                        />
                    </div>

                    {/* Filters */}
                    <div className="flex flex-wrap items-center gap-4 justify-center">
                        <div className="flex items-center gap-3">
                            <SlidersHorizontal size={18} className="text-slate-500" />
                            <span className="text-xs font-black text-slate-500 uppercase tracking-widest hidden sm:block">Filters:</span>
                        </div>

                        <select
                            value={selectedBrand}
                            onChange={(e) => setSelectedBrand(e.target.value)}
                            className="bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none focus:border-blue-500/50 transition-all"
                        >
                            {brands.map(b => <option key={b} value={b}>{b === 'All' ? 'All Makes' : b}</option>)}
                        </select>

                        <select
                            value={selectedFuel}
                            onChange={(e) => setSelectedFuel(e.target.value)}
                            className="bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none focus:border-blue-500/50 transition-all"
                        >
                            {fuelTypes.map(f => <option key={f} value={f}>{f === 'All' ? 'All Fuels' : f}</option>)}
                        </select>

                        <select
                            value={sortBy}
                            onChange={(e) => setSortBy(e.target.value)}
                            className="bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none focus:border-blue-500/50 transition-all"
                        >
                            <option>Newest</option>
                            <option>Price: High to Low</option>
                            <option>Price: Low to High</option>
                            <option>Ending Soon</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Results Grid */}
            <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-24 py-12">
                <div className="flex items-center justify-between mb-8">
                    <p className="text-slate-400 font-bold text-sm">
                        Showing <span className="text-white">{filteredVehicles.length}</span> active auctions
                    </p>
                    <div className="flex items-center gap-2 text-emerald-500 text-[10px] font-black uppercase tracking-tighter">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Live Update
                    </div>
                </div>

                {filteredVehicles.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredVehicles.map(vehicle => (
                            <VehicleCard key={vehicle.id} vehicle={vehicle} />
                        ))}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
                        <div className="w-20 h-20 rounded-3xl bg-slate-900 flex items-center justify-center text-slate-700">
                            <Car size={40} />
                        </div>
                        <div>
                            <h3 className="text-2xl font-bold text-white mb-2">No vehicles found</h3>
                            <p className="text-slate-500 font-medium">Try adjusting your filters or search terms.</p>
                        </div>
                        <button
                            onClick={() => { setSearchTerm(''); setSelectedBrand('All'); setSelectedFuel('All'); }}
                            className="px-6 py-2 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-500 transition-colors"
                        >
                            Clear All Filters
                        </button>
                    </div>
                )}
            </div>

            {/* Platform Trust Banner */}
            <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-24 mt-20">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-12 rounded-[2.5rem] bg-gradient-to-br from-slate-900 to-slate-800 border border-white/5">
                    <div className="flex flex-col items-center text-center space-y-4">
                        <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-500 flex items-center justify-center">
                            <Shield size={24} />
                        </div>
                        <h4 className="text-white font-bold uppercase tracking-tight">Verified Sellers Only</h4>
                        <p className="text-slate-500 text-xs font-medium leading-relaxed">Every merchant on DriveBid undergoes rigorous multi-step verification.</p>
                    </div>
                    <div className="flex flex-col items-center text-center space-y-4">
                        <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                            <Clock size={24} />
                        </div>
                        <h4 className="text-white font-bold uppercase tracking-tight">Real-Time Bidding</h4>
                        <p className="text-slate-500 text-xs font-medium leading-relaxed">Latency-free auction updates powered by our dedicated global network.</p>
                    </div>
                    <div className="flex flex-col items-center text-center space-y-4">
                        <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                            <Zap size={24} />
                        </div>
                        <h4 className="text-white font-bold uppercase tracking-tight">Instant Checkout</h4>
                        <p className="text-slate-500 text-xs font-medium leading-relaxed">Seamless asset transfer and payment settlement within 24 hours.</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Vehicles;
